import { createClient } from '@supabase/supabase-js';

// Get Supabase credentials from environment variables
const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing Supabase URL or Service Role Key. Make sure to add VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY to your environment variables.');
  process.exit(1);
}

// Initialize Supabase client with service role key to bypass RLS
const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

// Metro Manila coffee shop data
const coffeeShops = [
  {
    name: 'Toby\'s Estate',
    address: '5th Ave, Taguig, Metro Manila',
    operating_hours: 'Mon-Sun: 7:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1453614512568-c4024d13c247?ixlib=rb-1.2.1&auto=format&fit=crop&w=1489&q=80',
    latitude: 14.550133,
    longitude: 121.050774,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Commune',
    address: '36 Polaris St, Makati, 1210 Metro Manila',
    operating_hours: 'Mon-Sun: 8:00 AM - 9:00 PM',
    image_url: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.556300,
    longitude: 121.026217,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Habitual Coffee',
    address: '2135 Chino Roces Ave, Makati, 1231 Metro Manila',
    operating_hours: 'Mon-Sat: 8:00 AM - 7:00 PM, Sun: 9:00 AM - 6:00 PM',
    image_url: 'https://images.unsplash.com/photo-1516486392848-8b67ef89f113?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.551700,
    longitude: 121.013333,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'EDSA Beverage Design Group',
    address: 'EDSA, Makati, Metro Manila',
    operating_hours: 'Mon-Sat: 8:00 AM - 8:00 PM, Sun: Closed',
    image_url: 'https://images.unsplash.com/photo-1514481538271-cf9f99627524?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.556550,
    longitude: 121.023690,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Single Origin',
    address: 'Rockwell, Makati, Metro Manila',
    operating_hours: 'Mon-Sun: 7:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1498804103079-a6351b050096?ixlib=rb-1.2.1&auto=format&fit=crop&w=1489&q=80',
    latitude: 14.564440,
    longitude: 121.037778,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Café Adriatico',
    address: 'Remedios Circle, Malate, Manila, Metro Manila',
    operating_hours: 'Mon-Sun: 7:00 AM - 12:00 AM',
    image_url: 'https://images.unsplash.com/photo-1442975631115-c4f7b05b6107?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.574440,
    longitude: 120.987222,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: false,
    is_pet_friendly: false,
  },
  {
    name: 'The Curator Coffee & Cocktails',
    address: '134 Legazpi St, Makati, Metro Manila',
    operating_hours: 'Sun-Thu: 7:00 AM - 12:00 AM, Fri-Sat: 7:00 AM - 2:00 AM',
    image_url: 'https://images.unsplash.com/photo-1525610553991-2bede1a236e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.556550,
    longitude: 121.018889,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Narrative Coffee',
    address: 'BGC, Taguig, Metro Manila',
    operating_hours: 'Mon-Fri: 8:00 AM - 10:00 PM, Sat-Sun: 9:00 AM - 11:00 PM',
    image_url: 'https://images.unsplash.com/photo-1507133750040-4a8f57021571?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.547500,
    longitude: 121.046940,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: true,
    is_pet_friendly: true,
  },
  {
    name: 'The Coffee Academics',
    address: 'Uptown Mall, BGC, Metro Manila',
    operating_hours: 'Mon-Sun: 8:00 AM - 9:00 PM',
    image_url: 'https://images.unsplash.com/photo-1578474846511-04ba529f0b88?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.551410,
    longitude: 121.051410,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Yardstick Coffee',
    address: 'Legazpi Village, Makati, Metro Manila',
    operating_hours: 'Mon-Fri: 7:00 AM - 9:00 PM, Sat-Sun: 8:00 AM - 8:00 PM',
    image_url: 'https://images.unsplash.com/photo-1525193612562-0ec53b0e5d7c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.557780,
    longitude: 121.020556,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Coffee Empire',
    address: 'SM Megamall, Ortigas, Metro Manila',
    operating_hours: 'Mon-Sun: 10:00 AM - 9:00 PM',
    image_url: 'https://images.unsplash.com/photo-1530610476181-d83430b64dcd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.584170,
    longitude: 121.056667,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Kurēto Kafe',
    address: 'Tomas Morato, Quezon City, Metro Manila',
    operating_hours: 'Mon-Sun: 8:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1492158244976-29b84ba93025?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.631220,
    longitude: 121.026669,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: true,
    is_pet_friendly: true,
  }
];

async function populateDatabase() {
  console.log('Starting to populate coffee shops database...');
  
  try {
    // First, clear existing data (optional)
    // Uncomment the line below if you want to clear the table first
    // const { error: deleteError } = await supabase.from('coffee_shops').delete().not('id', 'is', null);
    // if (deleteError) throw deleteError;
    // console.log('Existing records deleted');
    
    // Insert coffee shops data
    const { data, error } = await supabase
      .from('coffee_shops')
      .insert(coffeeShops);
    
    if (error) throw error;
    
    console.log(`Successfully added ${coffeeShops.length} coffee shops to the database`);
    console.log(data);
  } catch (error) {
    console.error('Error populating database:', error);
  }
}

// Run the population script
populateDatabase();