import { db } from '../server/db';
import { coffeeShops, reviews } from '../shared/schema';
import { randomUUID } from 'crypto';

async function populateData() {
  console.log('Populating database with sample data...');

  // First, check if coffee shops already exist
  const existingShops = await db.select().from(coffeeShops);
  
  if (existingShops.length === 0) {
    console.log('Adding sample coffee shops...');
    
    // Create sample coffee shops
    const shopIds = await db.insert(coffeeShops).values([
      {
        id: randomUUID(),
        name: 'Commune Coffee',
        address: '36 Polaris St, Poblacion, Makati, Metro Manila',
        operating_hours: 'Monday - Sunday: 8:00 AM - 10:00 PM',
        image_url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        latitude: 14.5649,
        longitude: 121.0301,
        has_wifi: true,
        is_al_fresco: true,
        has_power_outlets: true,
        is_pet_friendly: true,
      },
      {
        id: randomUUID(),
        name: 'Toby\'s Estate',
        address: '120 Leviste St, Salcedo Village, Makati, Metro Manila',
        operating_hours: 'Monday - Sunday: 7:00 AM - 9:00 PM',
        image_url: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        latitude: 14.5577,
        longitude: 121.0209,
        has_wifi: true,
        is_al_fresco: false,
        has_power_outlets: true,
        is_pet_friendly: false,
      },
      {
        id: randomUUID(),
        name: 'The Curator Coffee & Cocktails',
        address: 'Legaspi Village, Makati, Metro Manila',
        operating_hours: 'Tuesday - Sunday: 8:00 AM - 12:00 AM',
        image_url: 'https://images.unsplash.com/photo-1542834369-f10ebf06d3e0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        latitude: 14.5539,
        longitude: 121.0156,
        has_wifi: true,
        is_al_fresco: false,
        has_power_outlets: true,
        is_pet_friendly: false,
      },
      {
        id: randomUUID(),
        name: 'EDSA Beverage Design Group',
        address: 'Makati, Metro Manila',
        operating_hours: 'Monday - Sunday: 9:00 AM - 8:00 PM',
        image_url: 'https://images.unsplash.com/photo-1521017432531-fbd92d768814?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        latitude: 14.5649,
        longitude: 121.0244,
        has_wifi: true,
        is_al_fresco: true,
        has_power_outlets: true,
        is_pet_friendly: true,
      },
      {
        id: randomUUID(),
        name: 'Habitual Coffee',
        address: '2135 Chino Roces Ave, Makati, Metro Manila',
        operating_hours: 'Tuesday - Sunday: 9:00 AM - 7:00 PM',
        image_url: 'https://images.unsplash.com/photo-1485808191679-5f86510681a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80',
        latitude: 14.5566,
        longitude: 121.0139,
        has_wifi: true,
        is_al_fresco: false,
        has_power_outlets: true,
        is_pet_friendly: false,
      }
    ]).returning({ id: coffeeShops.id });

    console.log(`Added ${shopIds.length} coffee shops.`);
  } else {
    console.log(`Found ${existingShops.length} existing coffee shops.`);
  }

  // Now add sample reviews
  const existingReviews = await db.select().from(reviews);
  
  if (existingReviews.length === 0) {
    console.log('Adding sample reviews...');
    
    // Get all coffee shop IDs
    const shops = await db.select({ id: coffeeShops.id }).from(coffeeShops);
    
    // Generate 3-5 reviews for each coffee shop
    const reviewValues = [];
    
    for (const shop of shops) {
      const numReviews = Math.floor(Math.random() * 3) + 3; // 3-5 reviews
      
      for (let i = 0; i < numReviews; i++) {
        // Generate a random review
        const rating = Math.floor(Math.random() * 3) + 3; // 3-5 stars
        const reviewerNames = [
          'Coffee Lover', 'Java Junkie', 'Espresso Explorer', 
          'Caffeine Addict', 'Latte Art Fan', 'Remote Worker',
          'Student', 'Freelancer', 'Coffee Snob', 'Local Foodie'
        ];
        const randomName = reviewerNames[Math.floor(Math.random() * reviewerNames.length)];
        
        const comments = [
          'Great ambiance and friendly staff. The coffee was exceptional!',
          'Love the aesthetic of this place. Would definitely come back.',
          'WiFi was fast and reliable. Perfect spot for remote work.',
          'One of my favorite coffee shops in the area. Highly recommended!',
          'Good coffee but a bit pricey. The atmosphere makes up for it though.',
          'Their pour-over is outstanding. Really brings out the flavor notes.',
          'Nice spot to study or work from. Not too noisy and great coffee.',
          'Amazing latte art and the pastries are delicious too.',
          'The baristas are knowledgeable and take pride in their craft.',
          'Cozy spot with decent coffee. Power outlets are a plus for working.'
        ];
        const randomComment = comments[Math.floor(Math.random() * comments.length)];
        
        // Create a random date in the past 30 days
        const visitDate = new Date();
        visitDate.setDate(visitDate.getDate() - Math.floor(Math.random() * 30));
        
        reviewValues.push({
          id: randomUUID(),
          coffee_shop_id: shop.id,
          user_name: randomName,
          rating,
          comment: randomComment,
          visit_date: visitDate,
          created_at: new Date()
        });
      }
    }
    
    if (reviewValues.length > 0) {
      await db.insert(reviews).values(reviewValues);
      console.log(`Added ${reviewValues.length} reviews.`);
    }
  } else {
    console.log(`Found ${existingReviews.length} existing reviews.`);
  }

  console.log('Database population completed!');
}

populateData()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('Error populating database:', err);
    process.exit(1);
  });