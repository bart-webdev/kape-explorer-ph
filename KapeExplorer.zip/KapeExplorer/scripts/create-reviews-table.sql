-- Create reviews table in Supabase
CREATE TABLE IF NOT EXISTS public.reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    coffee_shop_id UUID NOT NULL REFERENCES public.coffee_shops(id) ON DELETE CASCADE,
    user_id INTEGER,
    user_name TEXT NOT NULL,
    rating INTEGER NOT NULL,
    comment TEXT,
    visit_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create an index for faster retrieval of reviews by coffee shop
CREATE INDEX IF NOT EXISTS idx_reviews_coffee_shop_id ON public.reviews(coffee_shop_id);

-- Create an index for faster retrieval of reviews by user_id
CREATE INDEX IF NOT EXISTS idx_reviews_user_id ON public.reviews(user_id);