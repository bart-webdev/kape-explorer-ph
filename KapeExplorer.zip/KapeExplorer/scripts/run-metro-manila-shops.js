// Simple script to run the TypeScript file using tsx
// This is needed because we need to load environment variables properly

import { exec } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';

dotenv.config();

// Get __dirname equivalent in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Path to the TypeScript file
const scriptPath = join(__dirname, 'populate-metro-manila-shops.ts');

// Run the script with tsx
const child = exec(`npx tsx ${scriptPath}`, (error, stdout, stderr) => {
  if (error) {
    console.error(`Error executing script: ${error}`);
    return;
  }
  
  console.log(stdout);
  if (stderr) {
    console.error(stderr);
  }
});

// Forward script output to console
child.stdout.pipe(process.stdout);
child.stderr.pipe(process.stderr);