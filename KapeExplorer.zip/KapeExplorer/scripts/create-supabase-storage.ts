import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl || !supabaseServiceRoleKey) {
  console.error('Missing Supabase URL or Service Role Key. Make sure to add VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY to your environment variables.');
  process.exit(1);
}

// Using the service role key for admin operations
const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

async function createStorageBucket() {
  try {
    // Check if the bucket already exists
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketName = 'coffee-shop-images';
    
    if (!buckets || !buckets.find(bucket => bucket.name === bucketName)) {
      // Create the bucket
      const { data, error } = await supabase.storage.createBucket(bucketName, {
        public: true,
        fileSizeLimit: 5242880, // 5MB
        allowedMimeTypes: ['image/png', 'image/jpeg', 'image/jpg', 'image/webp']
      });
      
      if (error) {
        console.error('Error creating storage bucket:', error);
        return;
      }
      
      console.log('Storage bucket created successfully:', data);
    } else {
      console.log(`Storage bucket '${bucketName}' already exists.`);
    }
    
    // The bucket is created with public access
    console.log('Bucket is public and ready for image uploads.');
    
  } catch (err) {
    console.error('Unexpected error creating storage bucket:', err);
  }
}

createStorageBucket();