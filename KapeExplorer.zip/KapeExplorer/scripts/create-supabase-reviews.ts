import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';

// Get Supabase credentials from environment variables
const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing Supabase URL or Service Role Key. Make sure to add VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY to your environment variables.');
  process.exit(1);
}

// Initialize Supabase client with service role key to bypass RLS
const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

async function createReviewsTableInSupabase() {
  console.log('Checking if reviews table exists in Supabase...');
  
  try {
    // Check if the reviews table exists by trying to select from it
    const { data: tableExists, error: tableExistsError } = await supabase
      .from('reviews')
      .select('id')
      .limit(1);
    
    if (tableExistsError) {
      if (tableExistsError.code === '42P01') { // Table doesn't exist
        console.log('Reviews table does not exist yet. Creating it through the Supabase API is not possible directly.');
        console.log('Please create the reviews table in the Supabase dashboard with the following structure:');
        console.log(`
          - id: UUID (Primary Key, Default: gen_random_uuid())
          - coffee_shop_id: UUID (Foreign Key to coffee_shops.id, Not Null, On Delete: CASCADE)
          - user_id: INTEGER (Foreign Key to users.id, Nullable)
          - user_name: TEXT (Not Null)
          - rating: INTEGER (Not Null)
          - comment: TEXT (Nullable)
          - visit_date: TIMESTAMP WITH TIME ZONE (Default: NOW())
          - created_at: TIMESTAMP WITH TIME ZONE (Default: NOW())
        `);
        return;
      }
      
      console.error('Error checking reviews table:', tableExistsError);
      return;
    }
    
    console.log('Reviews table exists.');
    
    // Check if the table has data
    const { data: reviews, error: countError } = await supabase
      .from('reviews')
      .select('*', { count: 'exact' });
    
    if (countError) {
      console.error('Error counting reviews:', countError);
      return;
    }
    
    console.log(`Found ${reviews?.length || 0} existing reviews.`);
    
    // Only populate sample data if the table is empty
    if (!reviews || reviews.length === 0) {
      console.log('Populating sample reviews data...');
      
      // Get all coffee shop IDs
      const { data: coffeeShops, error: shopsError } = await supabase
        .from('coffee_shops')
        .select('id');
      
      if (shopsError) {
        console.error('Error fetching coffee shops:', shopsError);
        return;
      }
      
      if (!coffeeShops || coffeeShops.length === 0) {
        console.log('No coffee shops found to add reviews for.');
        return;
      }
      
      // Generate 3-5 reviews for each coffee shop
      const sampleReviews: Array<{
        coffee_shop_id: string;
        user_name: string;
        rating: number;
        comment: string;
        visit_date: string;
        created_at: string;
      }> = [];
      
      for (const shop of coffeeShops) {
        const numReviews = Math.floor(Math.random() * 3) + 3; // 3-5 reviews
        
        for (let i = 0; i < numReviews; i++) {
          // Generate a random review
          const rating = Math.floor(Math.random() * 3) + 3; // 3-5 stars
          const reviewerNames = [
            'Coffee Lover', 'Java Junkie', 'Espresso Explorer', 
            'Caffeine Addict', 'Latte Art Fan', 'Remote Worker',
            'Student', 'Freelancer', 'Coffee Snob', 'Local Foodie'
          ];
          const randomName = reviewerNames[Math.floor(Math.random() * reviewerNames.length)];
          
          const comments = [
            'Great ambiance and friendly staff. The coffee was exceptional!',
            'Love the aesthetic of this place. Would definitely come back.',
            'WiFi was fast and reliable. Perfect spot for remote work.',
            'One of my favorite coffee shops in the area. Highly recommended!',
            'Good coffee but a bit pricey. The atmosphere makes up for it though.',
            'Their pour-over is outstanding. Really brings out the flavor notes.',
            'Nice spot to study or work from. Not too noisy and great coffee.',
            'Amazing latte art and the pastries are delicious too.',
            'The baristas are knowledgeable and take pride in their craft.',
            'Cozy spot with decent coffee. Power outlets are a plus for working.'
          ];
          const randomComment = comments[Math.floor(Math.random() * comments.length)];
          
          // Create a random date in the past 30 days
          const visitDate = new Date();
          visitDate.setDate(visitDate.getDate() - Math.floor(Math.random() * 30));
          
          sampleReviews.push({
            coffee_shop_id: shop.id,
            user_name: randomName,
            rating,
            comment: randomComment,
            visit_date: visitDate.toISOString(),
            created_at: new Date().toISOString()
          });
        }
      }
      
      // Insert the sample reviews
      const { error: insertError } = await supabase
        .from('reviews')
        .insert(sampleReviews);
      
      if (insertError) {
        console.error('Error inserting sample reviews:', insertError);
        return;
      }
      
      console.log(`Successfully added ${sampleReviews.length} sample reviews.`);
    }
  } catch (error) {
    console.error('Unexpected error:', error);
  }
}

// Run the script
createReviewsTableInSupabase()
  .then(() => {
    console.log('Script completed.');
    process.exit(0);
  })
  .catch(err => {
    console.error('Script failed:', err);
    process.exit(1);
  });