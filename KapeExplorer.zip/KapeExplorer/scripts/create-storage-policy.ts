import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl || !supabaseServiceRoleKey) {
  console.error('Missing Supabase URL or Service Role Key. Make sure to add VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY to your environment variables.');
  process.exit(1);
}

// Using the service role key for admin operations
const supabase = createClient(supabaseUrl, supabaseServiceRoleKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

async function createStoragePolicy() {
  try {
    const bucketName = 'coffee-shop-images';
    
    // Create a policy that allows anyone to read from the bucket
    const { data: readPolicyData, error: readPolicyError } = await supabase.storage
      .from(bucketName)
      .createSignedUrl('test-policy.txt', 60);
    
    if (readPolicyError && readPolicyError.message !== 'The resource was not found') {
      console.error('Error creating read policy:', readPolicyError);
    } else {
      console.log('Read policy is configured correctly');
    }
    
    // Create a policy that allows authenticated users to upload to the bucket
    const { data: insertPolicyData, error: insertPolicyError } = await supabase.rpc('create_storage_policy', {
      bucket_name: bucketName,
      policy_name: `${bucketName}_insert_policy`,
      definition: 'true',
      policy_type: 'INSERT'
    });
    
    if (insertPolicyError) {
      // If the RPC doesn't exist or fails, try setting the policy directly
      console.log('RPC method not available, setting public access policy directly...');
      
      // Set bucket to public
      const { error: updateError } = await supabase.storage.updateBucket(bucketName, {
        public: true,
        allowedMimeTypes: ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'],
        fileSizeLimit: 5242880
      });
      
      if (updateError) {
        console.error('Error setting bucket to public:', updateError);
      } else {
        console.log('Bucket set to public successfully');
      }
    } else {
      console.log('Insert policy created successfully');
    }
    
  } catch (err) {
    console.error('Unexpected error creating storage policies:', err);
  }
}

createStoragePolicy();