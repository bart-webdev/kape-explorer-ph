import { createClient } from '@supabase/supabase-js';

// Get Supabase credentials from environment variables
const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing Supabase URL or Service Role Key. Make sure to add VITE_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY to your environment variables.');
  process.exit(1);
}

// Initialize Supabase client with service role key to bypass RLS
const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

// Additional Metro Manila coffee shop data (20 more shops)
const moreCoffeeShops = [
  {
    name: 'Starbucks Reserve',
    address: 'Powerplant Mall, Rockwell, Makati, Metro Manila',
    operating_hours: 'Mon-Sun: 7:00 AM - 11:00 PM',
    image_url: 'https://images.unsplash.com/photo-1559925393-8be0ec4767c8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1351&q=80',
    latitude: 14.5651,
    longitude: 121.0384,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Coffee Project',
    address: 'Eastwood City, Quezon City, Metro Manila',
    operating_hours: 'Mon-Sun: 7:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.6107,
    longitude: 121.0794,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: true,
    is_pet_friendly: true,
  },
  {
    name: 'Bo\'s Coffee',
    address: 'SM North EDSA, Quezon City, Metro Manila',
    operating_hours: 'Mon-Sun: 9:00 AM - 9:00 PM',
    image_url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1357&q=80',
    latitude: 14.6565,
    longitude: 121.0317,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Figaro Coffee',
    address: 'Glorietta, Makati, Metro Manila',
    operating_hours: 'Mon-Sun: 8:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?ixlib=rb-1.2.1&auto=format&fit=crop&w=1337&q=80',
    latitude: 14.5508,
    longitude: 121.0227,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Cafe Mary Grace',
    address: 'Greenbelt 2, Makati, Metro Manila',
    operating_hours: 'Mon-Sun: 7:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1600093463592-8e36ae95ef56?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5509,
    longitude: 121.0176,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: false,
    is_pet_friendly: false,
  },
  {
    name: 'Seattle\'s Best Coffee',
    address: 'SM Mall of Asia, Pasay, Metro Manila',
    operating_hours: 'Mon-Sun: 10:00 AM - 9:00 PM',
    image_url: 'https://images.unsplash.com/photo-1534040385115-33dcb3acba5b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5358,
    longitude: 120.9819,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Local Edition Coffee',
    address: 'Legazpi Village, Makati, Metro Manila',
    operating_hours: 'Mon-Sat: 8:00 AM - 7:00 PM, Sun: Closed',
    image_url: 'https://images.unsplash.com/photo-1559305616-3f99cd43e353?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5563,
    longitude: 121.0148,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Spotted Cafe',
    address: 'SM Aura Premier, Taguig, Metro Manila',
    operating_hours: 'Mon-Sun: 10:00 AM - 9:00 PM',
    image_url: 'https://images.unsplash.com/photo-1517914708689-adf0562b4439?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5463,
    longitude: 121.0475,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Arabica Coffee',
    address: 'W Fifth Building, BGC, Taguig, Metro Manila',
    operating_hours: 'Mon-Sun: 8:00 AM - 8:00 PM',
    image_url: 'https://images.unsplash.com/photo-1501747315-124a0eaca060?ixlib=rb-1.2.1&auto=format&fit=crop&w=1353&q=80',
    latitude: 14.5509,
    longitude: 121.0467,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Third Wave Coffee',
    address: 'Ortigas Center, Pasig, Metro Manila',
    operating_hours: 'Mon-Fri: 7:00 AM - 9:00 PM, Sat-Sun: 8:00 AM - 7:00 PM',
    image_url: 'https://images.unsplash.com/photo-1506619216599-9d16d0903dfd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5838,
    longitude: 121.0614,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Coffee Academics Manila',
    address: 'Uptown Parade, BGC, Taguig, Metro Manila',
    operating_hours: 'Mon-Sun: 8:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1523242942815-1ba7abed0d08?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5533,
    longitude: 121.0511,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Coffee Bean & Tea Leaf',
    address: 'Robinson\'s Galleria, Ortigas, Metro Manila',
    operating_hours: 'Mon-Sun: 9:00 AM - 9:00 PM',
    image_url: 'https://images.unsplash.com/photo-1521017432531-fbd92d768814?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5895,
    longitude: 121.0600,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Craft Coffee Revolution',
    address: 'The Grove by Rockwell, Pasig, Metro Manila',
    operating_hours: 'Mon-Sun: 7:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1489533119213-66a5cd877091?ixlib=rb-1.2.1&auto=format&fit=crop&w=1351&q=80',
    latitude: 14.5895,
    longitude: 121.0795,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'UCC Clockwork',
    address: 'Bluebay Walk, Macapagal Blvd, Pasay, Metro Manila',
    operating_hours: 'Mon-Sun: 11:00 AM - 11:00 PM',
    image_url: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5385,
    longitude: 120.9874,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Kuppa Roastery & Cafe',
    address: 'Shaw Boulevard, Mandaluyong, Metro Manila',
    operating_hours: 'Mon-Sun: 7:00 AM - 11:00 PM',
    image_url: 'https://images.unsplash.com/photo-1513267048331-5611cad62e41?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5774,
    longitude: 121.0433,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: true,
    is_pet_friendly: true,
  },
  {
    name: 'Cafe Ysabel',
    address: 'M. Paterno St, San Juan, Metro Manila',
    operating_hours: 'Mon-Sun: 10:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1445116572660-236099ec97a0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1351&q=80',
    latitude: 14.6038,
    longitude: 121.0323,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: false,
    is_pet_friendly: false,
  },
  {
    name: 'Fuel.ph',
    address: 'Aguirre Ave, BF Homes, Parañaque, Metro Manila',
    operating_hours: 'Mon-Sun: 8:00 AM - 11:00 PM',
    image_url: 'https://images.unsplash.com/photo-1499744937866-d7e566a20a61?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.4778,
    longitude: 121.0260,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: true,
  },
  {
    name: 'Type A Coffee',
    address: 'Kalayaan Avenue, Makati, Metro Manila',
    operating_hours: 'Mon-Sat: 7:00 AM - 8:00 PM, Sun: 8:00 AM - 6:00 PM',
    image_url: 'https://images.unsplash.com/photo-1519420638722-a2a5749c16e4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1360&q=80',
    latitude: 14.5633,
    longitude: 121.0306,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Crepe Amelie',
    address: 'Forbestown Road, BGC, Taguig, Metro Manila',
    operating_hours: 'Mon-Sun: 8:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1460760842241-97e491a806be?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    latitude: 14.5507,
    longitude: 121.0472,
    has_wifi: true,
    is_al_fresco: true,
    has_power_outlets: true,
    is_pet_friendly: false,
  },
  {
    name: 'Refinery',
    address: 'Rockwell, Makati, Metro Manila',
    operating_hours: 'Mon-Sun: 8:00 AM - 10:00 PM',
    image_url: 'https://images.unsplash.com/photo-1501846573261-db0b7c086c42?ixlib=rb-1.2.1&auto=format&fit=crop&w=1334&q=80',
    latitude: 14.5651,
    longitude: 121.0365,
    has_wifi: true,
    is_al_fresco: false,
    has_power_outlets: true,
    is_pet_friendly: false,
  }
];

async function populateMoreShops() {
  console.log('Starting to populate more coffee shops...');
  
  try {
    // Insert coffee shops data
    const { data, error } = await supabase
      .from('coffee_shops')
      .insert(moreCoffeeShops);
    
    if (error) throw error;
    
    console.log(`Successfully added ${moreCoffeeShops.length} more coffee shops to the database`);
    console.log(data);
  } catch (error) {
    console.error('Error populating database with more shops:', error);
  }
}

// Run the population script
populateMoreShops();