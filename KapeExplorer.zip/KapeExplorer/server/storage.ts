import { 
  users, type User, type InsertUser, 
  shopOwnership, type ShopOwnership, type InsertShopOwnership, 
  coffeeShops, type CoffeeShop,
} from "@shared/schema";
import { eq, and } from "drizzle-orm";
import * as bcrypt from "bcrypt";
import { db } from "./db";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Authentication methods
  validatePassword(plainPassword: string, hashedPassword: string): Promise<boolean>;
  hashPassword(password: string): Promise<string>;
  
  // Shop ownership methods
  getShopsByOwnerId(userId: number): Promise<CoffeeShop[]>;
  addShopOwnership(ownership: InsertShopOwnership): Promise<ShopOwnership>;
  isUserShopOwner(userId: number, shopId: string): Promise<boolean>;
}

export class DbStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Hash the password before storing
    const hashedPassword = await this.hashPassword(insertUser.password);
    
    const result = await db.insert(users).values({
      ...insertUser,
      password: hashedPassword
    }).returning();
    
    return result[0];
  }
  
  async validatePassword(plainPassword: string, hashedPassword: string): Promise<boolean> {
    return bcrypt.compare(plainPassword, hashedPassword);
  }
  
  async hashPassword(password: string): Promise<string> {
    const saltRounds = 10;
    return bcrypt.hash(password, saltRounds);
  }
  
  async getShopsByOwnerId(userId: number): Promise<CoffeeShop[]> {
    const result = await db
      .select({
        shop: coffeeShops
      })
      .from(shopOwnership)
      .innerJoin(coffeeShops, eq(shopOwnership.coffee_shop_id, coffeeShops.id))
      .where(eq(shopOwnership.user_id, userId));
    
    return result.map((r: { shop: CoffeeShop }) => r.shop);
  }
  
  async addShopOwnership(ownership: InsertShopOwnership): Promise<ShopOwnership> {
    const result = await db.insert(shopOwnership).values(ownership).returning();
    return result[0];
  }
  
  async isUserShopOwner(userId: number, shopId: string): Promise<boolean> {
    const result = await db
      .select()
      .from(shopOwnership)
      .where(
        and(
          eq(shopOwnership.user_id, userId),
          eq(shopOwnership.coffee_shop_id, shopId)
        )
      );
    
    return result.length > 0;
  }
}

export const storage = new DbStorage();
