import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertReviewSchema, coffeeShops, reviews } from "@shared/schema";
import passport from "./auth";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db } from "./db";
import { env } from "./env";
import { eq, desc } from "drizzle-orm";
import { randomUUID } from "crypto";
import { createClient } from '@supabase/supabase-js';

// Create Supabase client
const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const supabase = createClient(supabaseUrl, supabaseKey);

// Setup auth middleware
function setupAuth(app: Express) {
  // Setup session store with PostgreSQL
  const PostgresStore = connectPg(session);
  const sessionStore = new PostgresStore({
    // @ts-ignore - pg-simple-session expects a pg pool
    pool: db,
    createTableIfMissing: true,
  });

  // Session configuration
  app.use(
    session({
      store: sessionStore,
      secret: env.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        secure: env.NODE_ENV === "production",
      },
    })
  );

  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Register API routes
  app.post("/api/register", async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const validationResult = insertUserSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          error: "Invalid request body",
          details: validationResult.error.format(),
        });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      // Create the user in postgres (password will be hashed in the storage.createUser method)
      const user = await storage.createUser(req.body);

      // Also store the user in Supabase
      try {
        const supabaseUser = await supabase
          .from('users')
          .insert([{
            id: user.id,
            username: user.username,
            email: user.email,
            password: user.password, // Store the hashed password
            display_name: user.display_name || null,
            avatar_url: user.avatar_url || null,
            role: user.role,
            created_at: user.created_at,
          }])
          .select()
          .single();

        if (supabaseUser.error) {
          console.error("Error storing user in Supabase:", supabaseUser.error);
          // Continue anyway since the user is created in Postgres
        } else {
          console.log("User successfully stored in Supabase");
        }
      } catch (supabaseError) {
        console.error("Failed to store user in Supabase:", supabaseError);
        // Continue anyway since the user is created in Postgres
      }

      // Login the user
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ error: "Login failed after registration" });
        }
        return res.status(201).json(user);
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ error: "Failed to register user" });
    }
  });

  app.post("/api/login", (req: Request, res: Response, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ error: "Invalid username or password" });
      }
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        return res.status(200).json(user);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req: Request, res: Response) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/user", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    res.status(200).json(req.user);
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);

  // Coffee shop routes
  app.get("/api/coffee-shops", async (req: Request, res: Response) => {
    try {
      const { hasWifi, isAlFresco, hasPowerOutlets, isPetFriendly } = req.query;
      
      // Query builder
      let query = db.select().from(coffeeShops);
      
      if (hasWifi === 'true') {
        query = query.where(eq(coffeeShops.has_wifi, true));
      }
      
      if (isAlFresco === 'true') {
        query = query.where(eq(coffeeShops.is_al_fresco, true));
      }
      
      if (hasPowerOutlets === 'true') {
        query = query.where(eq(coffeeShops.has_power_outlets, true));
      }
      
      if (isPetFriendly === 'true') {
        query = query.where(eq(coffeeShops.is_pet_friendly, true));
      }
      
      const shops = await query;
      
      res.status(200).json(shops);
    } catch (error) {
      console.error("Error fetching coffee shops:", error);
      res.status(500).json({ error: "Failed to fetch coffee shops" });
    }
  });
  
  // Get single coffee shop
  app.get("/api/coffee-shops/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const shop = await db.select()
        .from(coffeeShops)
        .where(eq(coffeeShops.id, id))
        .limit(1);
      
      if (!shop || shop.length === 0) {
        return res.status(404).json({ error: "Coffee shop not found" });
      }
      
      res.status(200).json(shop[0]);
    } catch (error) {
      console.error("Error fetching coffee shop:", error);
      res.status(500).json({ error: "Failed to fetch coffee shop" });
    }
  });
  
  // Get reviews for a coffee shop
  app.get("/api/coffee-shops/:id/reviews", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const shopReviews = await db.select()
        .from(reviews)
        .where(eq(reviews.coffee_shop_id, id))
        .orderBy(desc(reviews.created_at));
      
      res.status(200).json(shopReviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ error: "Failed to fetch reviews" });
    }
  });
  
  // Add a review
  app.post("/api/coffee-shops/:id/reviews", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      // Validate request body
      const validationResult = insertReviewSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          error: "Invalid request body",
          details: validationResult.error.format(),
        });
      }
      
      // Create the review
      const reviewData = {
        ...req.body,
        coffee_shop_id: id,
        visit_date: req.body.visit_date || new Date(),
        created_at: new Date(),
        id: randomUUID(),
      };
      
      const result = await db.insert(reviews).values(reviewData).returning();
      
      // Also try to insert the review into Supabase
      try {
        const { error: supabaseError } = await supabase
          .from('reviews')
          .insert([{
            ...reviewData,
          }]);
        
        if (supabaseError) {
          console.error("Error inserting review into Supabase:", supabaseError);
          // Continue anyway since the review is saved in PostgreSQL
        }
      } catch (supabaseError) {
        console.error("Failed to insert review into Supabase:", supabaseError);
        // Continue anyway since the review is saved in PostgreSQL
      }
      
      res.status(201).json(result[0]);
    } catch (error) {
      console.error("Error adding review:", error);
      res.status(500).json({ error: "Failed to add review" });
    }
  });
  
  // Add a new coffee shop
  app.post("/api/coffee-shops", async (req: Request, res: Response) => {
    // Check if user is authenticated
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "You must be logged in to add a coffee shop" });
    }
    
    try {
      // Generate a new UUID for the coffee shop
      const coffeeShopId = randomUUID();
      
      // Prepare the coffee shop data
      const coffeeShopData = {
        ...req.body,
        id: coffeeShopId,
        created_at: new Date(),
      };
      
      // Insert into PostgreSQL
      const result = await db.insert(coffeeShops).values(coffeeShopData).returning();
      
      // Try to also insert into Supabase
      try {
        const { error: supabaseError } = await supabase
          .from('coffee_shops')
          .insert([{
            ...coffeeShopData,
          }]);
        
        if (supabaseError) {
          console.error("Error inserting coffee shop into Supabase:", supabaseError);
          // Continue anyway since the coffee shop is saved in PostgreSQL
        } else {
          // Add ownership record in Supabase
          const { error: ownershipError } = await supabase
            .from('shop_ownership')
            .insert([{
              user_id: req.user?.id,
              coffee_shop_id: coffeeShopId,
              created_at: new Date(),
            }]);
          
          if (ownershipError) {
            console.error("Error creating ownership record in Supabase:", ownershipError);
          }
        }
      } catch (supabaseError) {
        console.error("Failed to insert coffee shop into Supabase:", supabaseError);
        // Continue anyway since the coffee shop is saved in PostgreSQL
      }
      
      res.status(201).json(result[0]);
    } catch (error) {
      console.error("Error adding coffee shop:", error);
      res.status(500).json({ error: "Failed to add coffee shop" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
