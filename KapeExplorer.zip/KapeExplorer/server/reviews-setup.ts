import { supabase } from '../client/src/lib/supabaseClient';
import fs from 'fs';
import path from 'path';

async function setupReviewsTable() {
  try {
    console.log('Setting up reviews table in Supabase...');
    const sqlPath = path.join(__dirname, '../scripts/create-reviews-table.sql');
    const sqlContent = fs.readFileSync(sqlPath, 'utf8');
    
    const { error } = await supabase.rpc('exec_sql', { sql: sqlContent });
    
    if (error) {
      console.error('Error setting up reviews table:', error);
      return;
    }
    
    console.log('Reviews table successfully set up in Supabase!');
  } catch (err) {
    console.error('Unexpected error setting up reviews table:', err);
  }
}

setupReviewsTable();