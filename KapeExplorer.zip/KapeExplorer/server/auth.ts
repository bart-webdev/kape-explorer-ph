import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { storage } from "./storage";
import { User } from "@shared/schema";

// Configure local strategy for Passport
passport.use(
  new LocalStrategy(async (username, password, done) => {
    try {
      // Try to find user by username
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        // Also try finding by email if username lookup fails
        const userByEmail = await storage.getUserByEmail(username);
        
        if (!userByEmail) {
          return done(null, false, { message: "Incorrect username or email" });
        }
        
        // Validate password
        const isValid = await storage.validatePassword(password, userByEmail.password);
        if (!isValid) {
          return done(null, false, { message: "Incorrect password" });
        }
        
        return done(null, userByEmail);
      }
      
      // Validate password for user found by username
      const isValid = await storage.validatePassword(password, user.password);
      if (!isValid) {
        return done(null, false, { message: "Incorrect password" });
      }
      
      return done(null, user);
    } catch (err) {
      return done(err);
    }
  })
);

// Serialize and deserialize user
passport.serializeUser((user: any, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: number, done) => {
  try {
    const user = await storage.getUser(id);
    done(null, user);
  } catch (err) {
    done(err);
  }
});

export default passport;