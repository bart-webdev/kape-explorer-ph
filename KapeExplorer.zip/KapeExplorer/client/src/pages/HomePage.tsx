import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import ShopCard from '@/components/ShopCard';
import Filters from '@/components/Filters';
import AddCoffeeShop from '@/components/AddCoffeeShop';
import { fetchAllCoffeeShops } from '@/lib/supabaseClient';
import { Input } from '@/components/ui/input';
import { Search, Loader, Coffee, MousePointer, Briefcase, Compass } from 'lucide-react';

/**
 * HomePage component displaying the coffee shop directory
 */
const HomePage: React.FC = () => {
  // State for search and filters
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    hasWifi: false,
    isAlFresco: false,
    hasPowerOutlets: false,
    isPetFriendly: false
  });

  // Fetch coffee shops data
  const { data: coffeeShops, isLoading, error } = useQuery({
    queryKey: ['/api/coffee-shops'],
    queryFn: fetchAllCoffeeShops
  });

  // Filter coffee shops based on search query and selected filters
  const filteredShops = coffeeShops?.filter(shop => {
    // First filter by search query
    const matchesSearch = shop.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          shop.address.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (!matchesSearch) return false;
    
    // Then filter by amenities if any are selected
    if (filters.hasWifi && !shop.has_wifi) return false;
    if (filters.isAlFresco && !shop.is_al_fresco) return false;
    if (filters.hasPowerOutlets && !shop.has_power_outlets) return false;
    if (filters.isPetFriendly && !shop.is_pet_friendly) return false;
    
    return true;
  });

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  // Handle filter changes
  const handleFilterChange = (newFilters: typeof filters) => {
    setFilters(newFilters);
  };

  return (
    <main className="flex-grow">
      {/* Hero section */}
      <div className="bg-zinc-900 relative">
        {/* Subtle pattern overlay */}
        <div className="absolute inset-0 bg-amber-800/10"></div>
        
        {/* Background gear pattern */}
        <div className="absolute inset-0 overflow-hidden opacity-5">
          <div className="absolute -right-16 -top-16 w-64 h-64 border-8 border-amber-800 rounded-full"></div>
          <div className="absolute -left-20 top-40 w-40 h-40 border-4 border-amber-800 rounded-full"></div>
          <div className="absolute right-1/4 bottom-0 w-56 h-56 border-8 border-amber-800 rounded-full"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 relative z-10">
          <div className="text-center">
            <div className="flex justify-center mb-5">
              <Coffee size={48} className="text-amber-600" />
            </div>
            <h1 className="text-5xl font-['Bebas_Neue'] tracking-wider text-amber-100 sm:text-6xl md:text-7xl mb-2">
              FIND YOUR PERFECT <span className="text-amber-600">COFFEE SPOT</span>
            </h1>
            <div className="w-24 h-1 bg-amber-700 mx-auto my-6"></div>
            <p className="mt-6 max-w-2xl mx-auto text-xl text-zinc-300 font-['Roboto_Mono'] leading-relaxed">
              Discover the best coffee shops in Metro Manila, filtered by the amenities that matter to you.
            </p>
            
            {/* Feature highlights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
              <div className="bg-zinc-800/70 border border-zinc-700 p-6 industrial-shadow">
                <MousePointer className="h-10 w-10 text-amber-500 mx-auto mb-4" />
                <h3 className="text-lg font-['Space_Grotesk'] font-bold text-amber-100 mb-2">Easy Discovery</h3>
                <p className="text-zinc-400 text-sm">Browse coffee shops with an intuitive interface designed for quick exploration.</p>
              </div>
              
              <div className="bg-zinc-800/70 border border-zinc-700 p-6 industrial-shadow">
                <Briefcase className="h-10 w-10 text-amber-500 mx-auto mb-4" />
                <h3 className="text-lg font-['Space_Grotesk'] font-bold text-amber-100 mb-2">Remote Work Friendly</h3>
                <p className="text-zinc-400 text-sm">Find spaces with WiFi and power outlets perfect for productive work sessions.</p>
              </div>
              
              <div className="bg-zinc-800/70 border border-zinc-700 p-6 industrial-shadow">
                <Compass className="h-10 w-10 text-amber-500 mx-auto mb-4" />
                <h3 className="text-lg font-['Space_Grotesk'] font-bold text-amber-100 mb-2">Local Expertise</h3>
                <p className="text-zinc-400 text-sm">Curated selection of coffee shops across Metro Manila's diverse neighborhoods.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="industrial-divider"></div>

      {/* Main content area with filters and shop listings */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search and filter section */}
        <div className="md:flex md:items-center md:justify-between mb-8">
          <div className="flex-1 min-w-0">
            <h2 className="text-3xl font-['Space_Grotesk'] font-bold text-amber-100">
              Coffee Shops <span className="text-amber-600">Directory</span>
            </h2>
            <p className="text-zinc-400 mt-2">Browse our curated list of the best coffee destinations</p>
          </div>
          <div className="mt-4 flex md:mt-0 md:ml-4">
            {/* Search input */}
            <div className="relative rounded-sm industrial-shadow max-w-xs w-full">
              <Input
                type="text"
                name="search"
                id="search"
                className="industrial-input pl-10 pr-4 py-2 w-full"
                placeholder="Search shops..."
                value={searchQuery}
                onChange={handleSearchChange}
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                <Search className="h-5 w-5 text-amber-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-4">
          {/* Filters sidebar */}
          <div className="row-start-2 lg:row-start-1">
            <Filters filters={filters} onChange={handleFilterChange} />
            
            {/* Add Coffee Shop Component */}
            <div className="mt-6">
              <AddCoffeeShop onSuccess={() => {
                // Refresh the coffee shops list after a new one is added
                setSearchQuery('');
                setFilters({
                  hasWifi: false,
                  isAlFresco: false,
                  hasPowerOutlets: false,
                  isPetFriendly: false
                });
              }} />
            </div>
          </div>

          {/* Shop listings */}
          <div className="lg:col-span-3 row-start-1">
            {/* Loading state */}
            {isLoading && (
              <div className="bg-zinc-800 border border-zinc-700/70 p-8 industrial-shadow text-center min-h-[300px] flex items-center justify-center rounded">
                <div className="flex flex-col items-center">
                  <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-amber-600 mb-4">
                    <Loader className="h-16 w-16 text-amber-600" />
                  </div>
                  <p className="text-amber-100 font-['Poppins'] text-sm">Loading coffee shops...</p>
                </div>
              </div>
            )}

            {/* Error state */}
            {error && (
              <div className="bg-zinc-800 border border-zinc-700/70 p-8 industrial-shadow text-center min-h-[300px] flex items-center justify-center rounded">
                <div className="flex flex-col items-center">
                  <svg className="h-16 w-16 text-amber-600 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <p className="text-amber-100 font-['Poppins'] font-medium text-sm">
                    Connection Error
                  </p>
                  <p className="mt-2 text-zinc-400">
                    Unable to load coffee shops. Please try again later.
                  </p>
                </div>
              </div>
            )}

            {/* Empty state */}
            {!isLoading && !error && filteredShops?.length === 0 && (
              <div className="bg-zinc-800 border border-zinc-700/70 p-8 industrial-shadow text-center min-h-[300px] flex items-center justify-center rounded">
                <div className="flex flex-col items-center">
                  <svg className="h-16 w-16 text-amber-600 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  <p className="text-amber-100 font-['Poppins'] font-medium text-sm">
                    No Results Found
                  </p>
                  <p className="mt-2 text-zinc-400 max-w-md">
                    No coffee shops match your current search or filters. Try adjusting your criteria.
                  </p>
                </div>
              </div>
            )}

            {/* Shop listings grid */}
            {!isLoading && !error && filteredShops && filteredShops.length > 0 && (
              <>
                <p className="text-zinc-400 mb-4 font-['Poppins'] text-sm">
                  {filteredShops.length} coffee {filteredShops.length === 1 ? 'shop' : 'shops'} found
                </p>
                <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                  {filteredShops.map((shop) => (
                    <ShopCard key={shop.id} shop={shop} />
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </main>
  );
};

export default HomePage;
