import { useQuery } from '@tanstack/react-query';
import { useRoute, Link } from 'wouter';
import { ArrowLeft, MapPin, Share2, Check, X, Loader, Wifi, Zap, Heart, Clock, InfoIcon, Star, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import NotFound from './not-found';
import Reviews from '@/components/Reviews';
import { fetchCoffeeShopById } from '@/lib/supabaseClient';
import { CoffeeShop } from '@shared/schema';

/**
 * ShopDetailPage component for displaying detailed information about a coffee shop
 */
const ShopDetailPage: React.FC = () => {
  // Get the shop ID from the URL
  const [match, params] = useRoute('/shop/:id');
  const id = params?.id;

  // Fetch coffee shop data
  const { data: shop, isLoading, error } = useQuery<CoffeeShop | null>({
    queryKey: [`coffee-shop-${id}`],
    queryFn: () => fetchCoffeeShopById(id!),
    enabled: !!id // Only run query if ID exists
  });

  // Handle directions button click
  const handleDirectionsClick = () => {
    if (shop?.latitude && shop?.longitude) {
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${shop.latitude},${shop.longitude}`, '_blank');
    }
  };

  // Handle share button click
  const handleShareClick = () => {
    if (navigator.share) {
      navigator.share({
        title: `KapeExplorer PH - ${shop?.name}`,
        text: `Check out ${shop?.name} on KapeExplorer PH!`,
        url: window.location.href,
      });
    } else {
      // Fallback for browsers that don't support the Web Share API
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  if (!match) return <NotFound />;
  if (isLoading) return <LoadingState />;
  if (error) return <ErrorState />;
  if (!shop) return <NotFound />;

  // Random rating between 3.5 and 5.0
  const rating = (Math.random() * 1.5 + 3.5).toFixed(1);

  return (
    <main className="flex-grow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/" className="inline-flex items-center text-sm font-['Poppins'] font-medium text-amber-500 hover:text-amber-300 transition-colors duration-200 mb-6">
          <ArrowLeft className="mr-2 h-5 w-5" />
          Back to Coffee Shops
        </Link>

        <div className="card industrial-shadow overflow-hidden">
          {/* Hero image with overlay */}
          <div className="relative h-80 sm:h-[500px] w-full">
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 to-transparent opacity-70 z-10"></div>
            <img 
              src={shop.image_url || "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80"}
              alt={shop.name} 
              className="h-full w-full object-cover"
            />
            
            {/* Floating rating badge */}
            <div className="absolute top-4 right-4 z-20 bg-amber-800/90 text-amber-100 px-3 py-1.5 
              rounded flex items-center font-['Poppins'] font-medium border border-amber-700/70 shadow-lg">
              <Star className="h-4 w-4 mr-1.5 fill-amber-300 text-amber-300" />
              <span className="text-sm">{rating}</span>
            </div>
            
            {/* Title overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8 z-20">
              <h1 className="text-4xl sm:text-5xl font-['Bebas_Neue'] tracking-wider text-amber-100 mb-2">{shop.name}</h1>
              <p className="text-zinc-300 font-['Poppins'] text-sm sm:text-base">{shop.address}</p>
            </div>
          </div>
          
          {/* Action buttons */}
          <div className="bg-zinc-800 border-t border-b border-zinc-700 px-6 py-3 flex justify-end space-x-4">
            <Button 
              onClick={handleDirectionsClick}
              className="rounded bg-zinc-700 border border-zinc-600/70 hover:bg-zinc-600 text-zinc-200 shadow-md"
            >
              <MapPin className="mr-2 h-5 w-5 text-amber-500" />
              <span className="font-['Poppins'] text-sm">Directions</span>
            </Button>
            <Button 
              onClick={handleShareClick}
              className="rounded bg-amber-800 hover:bg-amber-700 text-amber-50 border border-amber-700 shadow-md"
            >
              <Share2 className="mr-2 h-5 w-5" />
              <span className="font-['Poppins'] text-sm">Share</span>
            </Button>
          </div>

          <div className="p-6 sm:p-8">
            {/* Details section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="col-span-2">
                <div className="mb-8">
                  <div className="flex items-center mb-4">
                    <InfoIcon className="h-5 w-5 text-amber-500 mr-2" />
                    <h2 className="text-2xl font-['Bebas_Neue'] tracking-wider text-amber-100">
                      ABOUT THIS COFFEE SHOP
                    </h2>
                  </div>
                  <div className="h-px w-full bg-zinc-800 mb-4"></div>
                  <p className="text-zinc-300 leading-relaxed">
                    {/* Default description since description field doesn't exist in schema */}
                    {`${shop.name} is a charming coffee shop located in ${shop.address}. 
                    The shop offers a cozy atmosphere perfect for enjoying premium coffee and delicious pastries.
                    Whether you're looking for a quick caffeine fix or a place to work or socialize, 
                    ${shop.name} provides an inviting space with friendly service.`}
                  </p>
                </div>

                {/* Amenities grid */}
                <div className="mb-8">
                  <div className="flex items-center mb-4">
                    <Check className="h-5 w-5 text-amber-500 mr-2" />
                    <h2 className="text-2xl font-['Bebas_Neue'] tracking-wider text-amber-100">
                      AMENITIES
                    </h2>
                  </div>
                  <div className="h-px w-full bg-zinc-800 mb-4"></div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className={`p-4 border rounded flex items-center ${shop.has_wifi ? 
                      'border-amber-700/70 bg-zinc-800/70' : 'border-zinc-700/70 bg-zinc-800/30 opacity-60'}`}>
                      <Wifi className={`h-5 w-5 mr-3 ${shop.has_wifi ? 'text-amber-500' : 'text-zinc-500'}`} />
                      <div>
                        <p className="font-['Poppins'] text-sm font-medium text-zinc-200">Wi-Fi</p>
                        <p className="text-xs text-zinc-400 mt-1">
                          {shop.has_wifi ? 'Free wireless internet available' : 'Not available'}
                        </p>
                      </div>
                    </div>
                    
                    <div className={`p-4 border rounded flex items-center ${shop.has_power_outlets ? 
                      'border-amber-700/70 bg-zinc-800/70' : 'border-zinc-700/70 bg-zinc-800/30 opacity-60'}`}>
                      <Zap className={`h-5 w-5 mr-3 ${shop.has_power_outlets ? 'text-amber-500' : 'text-zinc-500'}`} />
                      <div>
                        <p className="font-['Poppins'] text-sm font-medium text-zinc-200">Power Outlets</p>
                        <p className="text-xs text-zinc-400 mt-1">
                          {shop.has_power_outlets ? 'Available for customer use' : 'Not available'}
                        </p>
                      </div>
                    </div>
                    
                    <div className={`p-4 border rounded flex items-center ${shop.is_al_fresco ? 
                      'border-amber-700/70 bg-zinc-800/70' : 'border-zinc-700/70 bg-zinc-800/30 opacity-60'}`}>
                      <MapPin className={`h-5 w-5 mr-3 ${shop.is_al_fresco ? 'text-amber-500' : 'text-zinc-500'}`} />
                      <div>
                        <p className="font-['Poppins'] text-sm font-medium text-zinc-200">Al Fresco</p>
                        <p className="text-xs text-zinc-400 mt-1">
                          {shop.is_al_fresco ? 'Outdoor seating available' : 'Indoor seating only'}
                        </p>
                      </div>
                    </div>
                    
                    <div className={`p-4 border rounded flex items-center ${shop.is_pet_friendly ? 
                      'border-amber-700/70 bg-zinc-800/70' : 'border-zinc-700/70 bg-zinc-800/30 opacity-60'}`}>
                      <Heart className={`h-5 w-5 mr-3 ${shop.is_pet_friendly ? 'text-amber-500' : 'text-zinc-500'}`} />
                      <div>
                        <p className="font-['Poppins'] text-sm font-medium text-zinc-200">Pet Friendly</p>
                        <p className="text-xs text-zinc-400 mt-1">
                          {shop.is_pet_friendly ? 'Pets are welcome' : 'No pets allowed'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Location & Directions */}
                <div>
                  <div className="flex items-center mb-4">
                    <MapPin className="h-5 w-5 text-amber-500 mr-2" />
                    <h2 className="text-2xl font-['Bebas_Neue'] tracking-wider text-amber-100">
                      DIRECTIONS
                    </h2>
                  </div>
                  <div className="h-px w-full bg-zinc-800 mb-4"></div>
                  
                  <div className="bg-zinc-800 border border-zinc-700/70 p-6 rounded overflow-hidden industrial-shadow">
                    <div className="flex flex-col items-center text-center mb-4">
                      <MapPin className="mx-auto h-10 w-10 text-amber-600 mb-2" />
                      <p className="text-zinc-300 font-['Poppins'] text-base font-medium">
                        {shop.address}
                      </p>
                    </div>
                    
                    <Button 
                      onClick={handleDirectionsClick}
                      className="w-full rounded bg-amber-700 hover:bg-amber-600 text-amber-50 border border-amber-800 shadow-md"
                    >
                      <MapPin className="mr-2 h-5 w-5" />
                      <span className="font-['Poppins'] text-sm font-medium">Get Directions on Google Maps</span>
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Sidebar with info */}
              <div>
                <div className="bg-zinc-800 border border-zinc-700/70 rounded p-5 industrial-shadow">
                  <div className="flex items-center mb-4">
                    <Clock className="h-5 w-5 text-amber-500 mr-2" />
                    <h3 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100">
                      HOURS
                    </h3>
                  </div>
                  <div className="h-px w-full bg-zinc-700/80 mb-4"></div>
                  
                  <div className="font-['Poppins'] text-sm text-zinc-300">
                    {shop.operating_hours ? (
                      <p className="whitespace-pre-line">{shop.operating_hours}</p>
                    ) : (
                      <>
                        <div className="flex justify-between mb-2">
                          <span>Monday - Friday</span>
                          <span className="text-amber-300 font-medium">7:00 AM - 10:00 PM</span>
                        </div>
                        <div className="flex justify-between mb-2">
                          <span>Saturday</span>
                          <span className="text-amber-300 font-medium">8:00 AM - 11:00 PM</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Sunday</span>
                          <span className="text-amber-300 font-medium">8:00 AM - 9:00 PM</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>
                
                {/* More shop info */}
                <div className="mt-6 bg-zinc-800 border border-zinc-700/70 rounded p-5 industrial-shadow">
                  <h3 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100 mb-4">
                    GOOD TO KNOW
                  </h3>
                  <div className="h-px w-full bg-zinc-700/80 mb-4"></div>
                  
                  <ul className="space-y-3 text-sm text-zinc-300 font-['Poppins']">
                    <li className="flex items-start">
                      <span className="text-amber-500 mr-2">•</span>
                      {shop.is_pet_friendly ? 
                        'Dogs and other pets are welcome in this establishment' : 
                        'Not suitable for pets - please leave your furry friends at home'
                      }
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-500 mr-2">•</span>
                      {shop.has_wifi ? 
                        'Free WiFi available for customers - ask staff for password' : 
                        'No WiFi available - good spot for a digital detox'
                      }
                    </li>
                    <li className="flex items-start">
                      <span className="text-amber-500 mr-2">•</span>
                      {shop.has_power_outlets ? 
                        'Multiple power outlets available for charging devices' : 
                        'Limited or no power outlets - charge your devices beforehand'
                      }
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            
            {/* Reviews Section */}
            <div className="p-6 sm:p-8 border-t border-zinc-700/50 mt-8">
              <div className="flex items-center mb-6">
                <MessageSquare className="h-5 w-5 text-amber-500 mr-2" />
                <h2 className="text-2xl font-['Bebas_Neue'] tracking-wider text-amber-100">
                  COMMUNITY REVIEWS
                </h2>
              </div>
              <div className="h-px w-full bg-zinc-800 mb-6"></div>
              
              <Reviews coffeeShopId={shop.id} coffeeShopName={shop.name} />
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

// Loading state component
const LoadingState: React.FC = () => (
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div className="bg-zinc-800 border border-zinc-700/70 p-8 industrial-shadow text-center min-h-[300px] flex items-center justify-center rounded">
      <div className="flex flex-col items-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-amber-600 mb-4">
          <Loader className="h-16 w-16 text-amber-600" />
        </div>
        <p className="text-amber-100 font-['Poppins'] font-medium text-sm">Loading Coffee Shop Details</p>
      </div>
    </div>
  </div>
);

// Error state component
const ErrorState: React.FC = () => (
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div className="bg-zinc-800 border border-zinc-700/70 p-8 industrial-shadow text-center min-h-[300px] flex items-center justify-center rounded">
      <div className="flex flex-col items-center">
        <svg className="h-16 w-16 text-amber-600 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
        <p className="text-amber-100 font-['Poppins'] font-medium text-sm mb-2">
          Connection Error
        </p>
        <p className="text-zinc-400 mb-6 font-['Poppins']">
          Unable to load coffee shop details. Please try again later.
        </p>
        <Link href="/">
          <Button className="rounded bg-amber-800 hover:bg-amber-700 text-amber-50 border border-amber-700 shadow-md">
            <span className="font-['Poppins'] text-sm">Return to Home</span>
          </Button>
        </Link>
      </div>
    </div>
  </div>
);

export default ShopDetailPage;
