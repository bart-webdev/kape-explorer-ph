import { Button } from "@/components/ui/button";
import { AlertCircle, Home } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-zinc-900 text-zinc-200 px-4">
      <div className="w-full max-w-md bg-zinc-800 border border-zinc-700/70 p-8 industrial-shadow rounded">
        <div className="flex items-center mb-6">
          <AlertCircle className="h-8 w-8 text-amber-600 mr-3" />
          <h1 className="text-3xl font-['Bebas_Neue'] tracking-wider text-amber-100">404 - Page Not Found</h1>
        </div>
        
        <div className="h-px w-full bg-zinc-700/80 mb-6"></div>
        
        <p className="text-zinc-400 font-['Poppins'] mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        
        <Link href="/">
          <Button className="w-full rounded bg-amber-800 hover:bg-amber-700 text-amber-50 border border-amber-700 shadow-md">
            <Home className="h-5 w-5 mr-2" />
            <span className="font-['Poppins'] text-sm">Return to Home</span>
          </Button>
        </Link>
      </div>
    </div>
  );
}
