import { createClient } from '@supabase/supabase-js';
import type { CoffeeShop, Review, InsertReview, InsertUser, User, InsertCoffeeShop } from '@shared/schema';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase URL or Anon Key. Make sure to add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your environment variables.');
}

/**
 * Supabase client instance for database interactions
 */
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * Upload image to Supabase storage
 * @param file - The file to upload
 * @returns Promise with the public URL of the uploaded file
 */
export async function uploadImage(file: File): Promise<string> {
  try {
    // Generate a unique file name using timestamp and random string
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
    
    // Upload the file to the coffee-shop-images bucket
    const { data, error: uploadError } = await supabase.storage
      .from('coffee-shop-images')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false
      });
    
    if (uploadError) {
      console.error('Error uploading image:', uploadError);
      throw new Error(`Failed to upload image: ${uploadError.message}`);
    }
    
    // Get the public URL
    const { data: urlData } = supabase.storage
      .from('coffee-shop-images')
      .getPublicUrl(fileName);
    
    return urlData.publicUrl;
  } catch (err) {
    if (err instanceof Error) {
      throw err;
    }
    console.error('Unexpected error uploading image:', err);
    throw new Error('An unexpected error occurred while uploading the image. Please try again.');
  }
}

/**
 * Register a new user in Supabase
 * @param userData - User data to register
 * @returns Promise<User>
 */
export async function registerUser(userData: InsertUser): Promise<User> {
  try {
    const { data, error } = await supabase
      .from('users')
      .insert([userData])
      .select()
      .single();
    
    if (error) {
      console.error('Error registering user:', error);
      throw new Error(`Failed to register user: ${error.message}`);
    }
    
    return data;
  } catch (err) {
    if (err instanceof Error) {
      throw err;
    }
    console.error('Unexpected error registering user:', err);
    throw new Error('An unexpected error occurred during registration. Please try again.');
  }
}

/**
 * Get user by username
 * @param username - Username to look up
 * @returns Promise<User | null>
 */
export async function getUserByUsername(username: string): Promise<User | null> {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('username', username)
      .single();
    
    if (error) {
      if (error.code === 'PGRST116') {
        // No rows returned
        return null;
      }
      console.error('Error fetching user by username:', error);
      throw new Error(`Failed to fetch user: ${error.message}`);
    }
    
    return data;
  } catch (err) {
    if (err instanceof Error) {
      throw err;
    }
    console.error('Unexpected error fetching user:', err);
    throw new Error('An unexpected error occurred while fetching user data. Please try again.');
  }
}

/**
 * Fetch all coffee shops from the database
 * @returns Promise<CoffeeShop[]>
 */
export async function fetchAllCoffeeShops(): Promise<CoffeeShop[]> {
  try {
    const { data, error } = await supabase
      .from('coffee_shops')
      .select('*');

    if (error) {
      console.error('Error fetching coffee shops:', error);
      return []; // Return empty array instead of throwing
    }

    return data || [];
  } catch (err) {
    console.error('Unexpected error fetching coffee shops:', err);
    return []; // Return empty array on any error
  }
}

/**
 * Fetch a single coffee shop by ID
 * @param id - The UUID of the coffee shop
 * @returns Promise<CoffeeShop | null>
 */
export async function fetchCoffeeShopById(id: string): Promise<CoffeeShop | null> {
  const { data, error } = await supabase
    .from('coffee_shops')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    if (error.code === 'PGRST116') {
      // PGRST116 indicates no rows returned
      return null;
    }
    console.error('Error fetching coffee shop:', error);
    throw new Error(`Failed to fetch coffee shop: ${error.message}`);
  }

  return data;
}

/**
 * Fetch coffee shops filtered by amenities
 * @param filters - Object containing filter criteria
 * @returns Promise<CoffeeShop[]>
 */
export async function fetchCoffeeShopsWithFilters(filters: {
  hasWifi?: boolean,
  isAlFresco?: boolean,
  hasPowerOutlets?: boolean,
  isPetFriendly?: boolean
}): Promise<CoffeeShop[]> {
  let query = supabase.from('coffee_shops').select('*');

  if (filters.hasWifi) {
    query = query.eq('has_wifi', true);
  }
  if (filters.isAlFresco) {
    query = query.eq('is_al_fresco', true);
  }
  if (filters.hasPowerOutlets) {
    query = query.eq('has_power_outlets', true);
  }
  if (filters.isPetFriendly) {
    query = query.eq('is_pet_friendly', true);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching filtered coffee shops:', error);
    throw new Error(`Failed to fetch filtered coffee shops: ${error.message}`);
  }

  return data || [];
}

/**
 * Fetch reviews for a specific coffee shop
 * @param coffeeShopId - The UUID of the coffee shop
 * @returns Promise<Review[]>
 */
export async function fetchReviewsByCoffeeShopId(coffeeShopId: string): Promise<Review[]> {
  try {
    const { data, error } = await supabase
      .from('reviews')
      .select('*')
      .eq('coffee_shop_id', coffeeShopId)
      .order('created_at', { ascending: false });

    if (error) {
      // If the table doesn't exist, Supabase will return a '42P01' error
      if (error.code === '42P01') {
        console.error('Reviews table does not exist:', error);
        return [];
      }
      
      console.error('Error fetching reviews:', error);
      return [];
    }

    return data || [];
  } catch (err) {
    console.error('Unexpected error fetching reviews:', err);
    return [];
  }
}

/**
 * Add a new review for a coffee shop
 * @param review - The review data to be submitted
 * @returns Promise<Review>
 */
export async function addReview(review: InsertReview): Promise<Review> {
  try {
    // Use the API endpoint directly instead of Supabase
    const response = await fetch(`/api/coffee-shops/${review.coffee_shop_id}/reviews`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(review),
      credentials: 'include', // Important for authentication cookies
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      console.error('Error adding review:', errorData);
      throw new Error(errorData.error || 'Failed to add review');
    }
    
    return await response.json();
  } catch (err) {
    if (err instanceof Error) {
      throw err; // Re-throw if it's already an Error object with a message
    }
    console.error('Unexpected error adding review:', err);
    throw new Error('An unexpected error occurred while adding your review. Please try again.');
  }
}

/**
 * Calculate average rating for a coffee shop
 * @param coffeeShopId - The UUID of the coffee shop
 * @returns Promise<number>
 */
export async function calculateAverageRating(coffeeShopId: string): Promise<number> {
  const reviews = await fetchReviewsByCoffeeShopId(coffeeShopId);
  
  if (reviews.length === 0) {
    return 0;
  }
  
  const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
  return parseFloat((totalRating / reviews.length).toFixed(1));
}

/**
 * Add a new coffee shop
 * @param coffeeShopData - Coffee shop data to add
 * @returns Promise<CoffeeShop>
 */
export async function addCoffeeShop(coffeeShopData: InsertCoffeeShop): Promise<CoffeeShop> {
  try {
    // We'll use the API endpoint we created instead of direct Supabase access
    const response = await fetch('/api/coffee-shops', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(coffeeShopData),
      credentials: 'include', // Important for authentication cookies
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to add coffee shop');
    }
    
    return await response.json();
  } catch (err) {
    if (err instanceof Error) {
      throw err;
    }
    console.error('Unexpected error adding coffee shop:', err);
    throw new Error('An unexpected error occurred while adding the coffee shop. Please try again.');
  }
}
