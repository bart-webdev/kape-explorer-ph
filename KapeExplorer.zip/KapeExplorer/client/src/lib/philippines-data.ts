// List of Philippines regions and provinces

export interface Province {
  name: string;
  cities: string[];
}

export const provinces: Province[] = [
  {
    name: "NCR (National Capital Region)",
    cities: [
      "Manila",
      "Quezon City",
      "Caloocan",
      "Las Piñas",
      "Makati",
      "Malabon",
      "Mandaluyong",
      "Marikina",
      "Muntinlupa",
      "Navotas",
      "Parañaque",
      "Pasay",
      "Pasig",
      "San Juan",
      "Taguig",
      "Valenzuela",
      "Pateros"
    ]
  },
  {
    name: "Batangas",
    cities: [
      "Batangas City",
      "Lipa",
      "Tanauan",
      "Santo Tomas",
      "Bauan",
      "San Jose",
      "Nasugbu",
      "Calatagan",
      "Balayan",
      "Lemery"
    ]
  },
  {
    name: "Bulacan",
    cities: [
      "Malolos",
      "Meycauayan",
      "San Jose del Monte",
      "Baliuag",
      "Plaridel",
      "Bustos",
      "Marilao",
      "Obando",
      "Calumpit",
      "Hagonoy"
    ]
  },
  {
    name: "Cavite",
    cities: [
      "Cavite City",
      "Trece Martires",
      "Dasmariñas",
      "General Trias",
      "Imus",
      "Kawit",
      "Tagaytay",
      "Silang",
      "Bacoor",
      "Carmona"
    ]
  },
  {
    name: "Laguna",
    cities: [
      "Santa Rosa",
      "Biñan",
      "San Pedro",
      "Calamba",
      "Los Baños",
      "Cabuyao",
      "San Pablo",
      "Pagsanjan",
      "Pila",
      "Nagcarlan"
    ]
  },
  {
    name: "Rizal",
    cities: [
      "Antipolo",
      "Cainta",
      "Taytay",
      "Angono",
      "Binangonan",
      "Cardona",
      "Morong",
      "Tanay",
      "Teresa",
      "Rodriguez"
    ]
  },
  {
    name: "Pampanga",
    cities: [
      "Angeles City",
      "San Fernando",
      "Mabalacat",
      "Guagua",
      "Lubao",
      "Floridablanca",
      "Porac",
      "Bacolor",
      "Mexico",
      "Arayat"
    ]
  },
  {
    name: "Cebu",
    cities: [
      "Cebu City",
      "Mandaue",
      "Lapu-Lapu",
      "Talisay",
      "Danao",
      "Toledo",
      "Carcar",
      "Bogo",
      "Naga",
      "Minglanilla"
    ]
  },
  {
    name: "Davao",
    cities: [
      "Davao City",
      "Tagum",
      "Panabo",
      "Digos",
      "Mati",
      "Samal",
      "Malita",
      "Nabunturan",
      "Maco",
      "Kapalong"
    ]
  },
  {
    name: "Iloilo",
    cities: [
      "Iloilo City",
      "Passi",
      "Oton",
      "Pavia",
      "Santa Barbara",
      "Leganes",
      "Dumangas",
      "Jaro",
      "Molo",
      "La Paz"
    ]
  }
];

// Working days array for multi-select
export const workingDays = [
  { value: "Monday", label: "Monday" },
  { value: "Tuesday", label: "Tuesday" },
  { value: "Wednesday", label: "Wednesday" },
  { value: "Thursday", label: "Thursday" },
  { value: "Friday", label: "Friday" },
  { value: "Saturday", label: "Saturday" },
  { value: "Sunday", label: "Sunday" }
];