import { Link } from 'wouter';
import { CoffeeShop } from '@shared/schema';
import { Wifi, MapPin, Zap, Heart, Star } from 'lucide-react';

interface ShopCardProps {
  shop: CoffeeShop;
}

/**
 * ShopCard component for displaying individual coffee shop information
 */
const ShopCard: React.FC<ShopCardProps> = ({ shop }) => {
  return (
    <Link href={`/shop/${shop.id}`}>
      <div className="card group cursor-pointer relative">
        {/* Top right rating badge */}
        <div className="absolute top-2 right-2 z-10 bg-amber-800 text-amber-100 px-2 py-1 
          rounded-sm flex items-center font-['Roboto_Mono'] font-medium border border-amber-900">
          <Star className="h-3 w-3 mr-1 fill-amber-300 text-amber-300" />
          <span className="text-xs tracking-wider">{(Math.random() * 2 + 3).toFixed(1)}</span>
        </div>
        
        <div className="relative h-48 w-full overflow-hidden">
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 to-transparent opacity-50 
            group-hover:opacity-40 transition-opacity z-0"></div>
          
          <img 
            src={shop.image_url || 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'}
            alt={shop.name} 
            className="h-full w-full object-cover transform group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        
        <div className="p-4 border-t border-zinc-700">
          <h3 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100">{shop.name}</h3>
          <p className="text-sm text-zinc-400 mt-1 font-['Roboto_Mono']">{shop.address}</p>
          
          <div className="h-px w-full bg-zinc-800 my-3"></div>
          
          <div className="flex flex-wrap gap-2 mt-3">
            {shop.has_wifi && (
              <span className="industrial-badge flex items-center">
                <Wifi className="mr-1 h-3 w-3 text-amber-500" />
                WI-FI
              </span>
            )}
            {shop.is_al_fresco && (
              <span className="industrial-badge flex items-center">
                <MapPin className="mr-1 h-3 w-3 text-amber-500" />
                AL FRESCO
              </span>
            )}
            {shop.has_power_outlets && (
              <span className="industrial-badge flex items-center">
                <Zap className="mr-1 h-3 w-3 text-amber-500" />
                POWER
              </span>
            )}
            {shop.is_pet_friendly && (
              <span className="industrial-badge flex items-center">
                <Heart className="mr-1 h-3 w-3 text-amber-500" />
                PET FRIENDLY
              </span>
            )}
          </div>
          
          <button className="mt-4 w-full py-2 text-center text-sm font-['Roboto_Mono'] tracking-wider
            bg-amber-800 text-amber-100 border-2 border-amber-900 rounded-sm hover:bg-amber-700
            transition-colors duration-200 uppercase">
            View Details
          </button>
        </div>
      </div>
    </Link>
  );
};

export default ShopCard;
