import { Coffee } from 'lucide-react';

/**
 * Buy Me A Coffee button component for donations
 */
const BuyMeACoffeeButton: React.FC = () => {
  // Replace 'YOUR_USERNAME' with your actual Buy Me A Coffee username
  const buyMeACoffeeUrl = 'https://www.buymeacoffee.com/YOUR_USERNAME';

  return (
    <a 
      href={buyMeACoffeeUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center px-6 py-3 border-2 border-amber-900 text-base font-['Roboto_Mono'] 
        uppercase tracking-wider rounded-sm shadow-md text-amber-50 
        bg-amber-800 hover:bg-amber-700 focus:outline-none transition-all duration-200
        hover:shadow-lg transform hover:-translate-y-0.5"
    >
      <Coffee className="mr-2 -ml-1 h-5 w-5 text-amber-300" />
      Support this project
    </a>
  );
};

export default BuyMeACoffeeButton;
