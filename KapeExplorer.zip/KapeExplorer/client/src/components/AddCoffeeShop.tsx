import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { 
  Loader, 
  Image as ImageIcon,
  Clock,
  MapPin,
  Upload
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { insertCoffeeShopSchema, InsertCoffeeShop } from '@shared/schema';
import { z } from 'zod';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest } from '@/lib/queryClient';
import { addCoffeeShop as submitCoffeeShop, uploadImage } from '@/lib/supabaseClient';
import { provinces, workingDays } from '@/lib/philippines-data';
import { cn } from '@/lib/utils';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';

// Define the form schema for adding a coffee shop
const addCoffeeShopSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  address: z.string().min(5, 'Address must be at least 5 characters'),
  province: z.string().min(2, 'Province is required'),
  city: z.string().min(2, 'City is required'),
  operation_type: z.enum(['everyday', 'custom']),
  opening_time: z.string().min(1, 'Opening time is required'),
  closing_time: z.string().min(1, 'Closing time is required'),
  custom_days: z.array(z.string()).optional(),
  image_file: z.instanceof(File).optional().or(z.any()), // Allow File or undefined
  image_url: z.string().optional(),
  has_wifi: z.boolean().default(false),
  is_al_fresco: z.boolean().default(false),
  has_power_outlets: z.boolean().default(false),
  is_pet_friendly: z.boolean().default(false),
  location: z.object({
    lat: z.number().optional(),
    lng: z.number().optional()
  }).optional()
});

type AddCoffeeShopFormData = z.infer<typeof addCoffeeShopSchema>;

interface AddCoffeeShopProps {
  onSuccess?: () => void;
}

const AddCoffeeShop: React.FC<AddCoffeeShopProps> = ({ onSuccess }) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedProvince, setSelectedProvince] = useState<string>(provinces[0].name);
  const [availableCities, setAvailableCities] = useState<string[]>(provinces[0].cities);
  
  const { 
    register, 
    handleSubmit, 
    control,
    watch,
    formState: { errors, isSubmitting }, 
    reset, 
    setValue,
    getValues
  } = useForm<AddCoffeeShopFormData>({
    resolver: zodResolver(addCoffeeShopSchema),
    defaultValues: {
      name: '',
      description: '',
      address: '',
      province: provinces[0].name,
      city: provinces[0].cities[0],
      operation_type: 'everyday',
      opening_time: '08:00',
      closing_time: '22:00',
      custom_days: [],
      image_url: '',
      has_wifi: false,
      is_al_fresco: false,
      has_power_outlets: false,
      is_pet_friendly: false,
      location: {
        lat: undefined,
        lng: undefined
      }
    }
  });
  
  const operationType = watch('operation_type');
  const watchProvince = watch('province');
  
  // Update cities when province changes
  useEffect(() => {
    if (watchProvince) {
      const province = provinces.find(p => p.name === watchProvince);
      if (province) {
        setAvailableCities(province.cities);
        setValue('city', province.cities[0]);
      }
    }
  }, [watchProvince, setValue]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (5MB max)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: 'File too large',
          description: 'Image must be less than 5MB',
          variant: 'destructive',
        });
        return;
      }
      
      // Check file type
      if (!['image/jpeg', 'image/png', 'image/jpg', 'image/webp'].includes(file.type)) {
        toast({
          title: 'Invalid file type',
          description: 'Please upload a JPEG, PNG or WebP image',
          variant: 'destructive',
        });
        return;
      }
      
      // Set the file in form data
      setValue('image_file', file);
      
      // Create a preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const addCoffeeShopMutation = useMutation({
    mutationFn: async (data: AddCoffeeShopFormData) => {
      let imageUrl = data.image_url;
      
      // Upload image if present
      if (data.image_file instanceof File) {
        setIsUploading(true);
        try {
          imageUrl = await uploadImage(data.image_file);
        } catch (error) {
          throw new Error(`Failed to upload image: ${error}`);
        } finally {
          setIsUploading(false);
        }
      }
      
      // Format operating hours
      let operating_hours;
      if (data.operation_type === 'everyday') {
        operating_hours = `Monday-Sunday: ${data.opening_time} - ${data.closing_time}`;
      } else {
        const selectedDays = data.custom_days?.join(', ') || '';
        operating_hours = `${selectedDays}: ${data.opening_time} - ${data.closing_time}`;
      }
      
      // Prepare shop data
      const shopData = {
        name: data.name,
        description: data.description,
        address: data.address,
        city: data.city,
        operating_hours,
        image_url: imageUrl || '',
        has_wifi: data.has_wifi,
        is_al_fresco: data.is_al_fresco,
        has_power_outlets: data.has_power_outlets,
        is_pet_friendly: data.is_pet_friendly,
        latitude: data.location?.lat?.toString() || '',
        longitude: data.location?.lng?.toString() || ''
      };
      
      return await submitCoffeeShop(shopData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/coffee-shops'] });
      reset();
      setShowForm(false);
      setImagePreview(null);
      toast({
        title: 'Coffee shop added!',
        description: 'Your coffee shop has been added to our directory.',
        variant: 'default',
      });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: 'Error adding coffee shop',
        description: `${error}`,
        variant: 'destructive',
      });
    }
  });

  const onSubmit = (data: AddCoffeeShopFormData) => {
    addCoffeeShopMutation.mutate(data);
  };

  // If user is not logged in, show sign-in button
  if (!user) {
    return (
      <div className="bg-zinc-800/50 border border-zinc-700/40 rounded p-6 text-center">
        <h3 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100 mb-4">
          ADD A COFFEE SHOP
        </h3>
        <p className="text-zinc-400 font-['Poppins'] mb-4">
          Sign in to add a new coffee shop to our directory.
        </p>
        <Button 
          asChild
          className="rounded bg-amber-700 hover:bg-amber-600 text-amber-50 text-sm border border-amber-800 shadow-md"
        >
          <a href="/auth">Sign In to Add Coffee Shop</a>
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-zinc-800 border border-zinc-700/70 rounded p-6 shadow-md">
      <h3 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100 mb-4">
        ADD A COFFEE SHOP
      </h3>
      
      {!showForm ? (
        <div className="text-center">
          <p className="text-zinc-400 font-['Poppins'] mb-4">
            Know a great coffee shop that's not in our directory? Add it here!
          </p>
          <Button 
            onClick={() => setShowForm(true)}
            className="rounded bg-amber-700 hover:bg-amber-600 text-amber-50 border border-amber-800 shadow-md"
          >
            Add New Coffee Shop
          </Button>
        </div>
      ) : (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="name">Coffee Shop Name</Label>
            <Input
              id="name"
              {...register("name")}
              className="bg-zinc-900 border-zinc-700 text-zinc-200 font-['Poppins']"
            />
            {errors.name && (
              <p className="text-sm text-red-500 mt-1">{errors.name.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              {...register("description")}
              className="bg-zinc-900 border-zinc-700 text-zinc-200 min-h-[100px] font-['Poppins']"
              placeholder="Tell us about this coffee shop..."
            />
            {errors.description && (
              <p className="text-sm text-red-500 mt-1">{errors.description.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="address">Address</Label>
            <Textarea
              id="address"
              {...register("address")}
              className="bg-zinc-900 border-zinc-700 text-zinc-200 font-['Poppins']"
              placeholder="Full address of the coffee shop"
            />
            {errors.address && (
              <p className="text-sm text-red-500 mt-1">{errors.address.message}</p>
            )}
          </div>
          
          {/* Province and City Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="province">Province</Label>
              <Controller
                name="province"
                control={control}
                render={({ field }) => (
                  <Select
                    onValueChange={(value) => {
                      field.onChange(value);
                      const province = provinces.find(p => p.name === value);
                      if (province) {
                        setSelectedProvince(value);
                        setAvailableCities(province.cities);
                        setValue('city', province.cities[0]);
                      }
                    }}
                    value={field.value}
                  >
                    <SelectTrigger className="bg-zinc-900 border-zinc-700 text-zinc-200 font-['Poppins']">
                      <SelectValue placeholder="Select Province" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-700 text-zinc-200 max-h-[300px]">
                      {provinces.map((province) => (
                        <SelectItem key={province.name} value={province.name}>
                          {province.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.province && (
                <p className="text-sm text-red-500 mt-1">{errors.province.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="city">City</Label>
              <Controller
                name="city"
                control={control}
                render={({ field }) => (
                  <Select
                    onValueChange={field.onChange}
                    value={field.value}
                  >
                    <SelectTrigger className="bg-zinc-900 border-zinc-700 text-zinc-200 font-['Poppins']">
                      <SelectValue placeholder="Select City" />
                    </SelectTrigger>
                    <SelectContent className="bg-zinc-900 border-zinc-700 text-zinc-200 max-h-[300px]">
                      {availableCities.map((city) => (
                        <SelectItem key={city} value={city}>
                          {city}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.city && (
                <p className="text-sm text-red-500 mt-1">{errors.city.message}</p>
              )}
            </div>
          </div>
          
          {/* Map Location Picker Placeholder */}
          <div className="bg-zinc-900 border border-zinc-700 rounded p-4">
            <Label className="flex items-center mb-2">
              <MapPin className="mr-2 h-4 w-4" />
              Location on Map (Coming soon)
            </Label>
            <div className="bg-zinc-800 h-[200px] flex items-center justify-center text-zinc-500 border border-dashed border-zinc-700 rounded">
              <p>Map location picker will be available soon</p>
            </div>
          </div>
          
          {/* Operating Hours Section */}
          <div className="bg-zinc-900 border border-zinc-700 rounded p-4">
            <Label className="flex items-center mb-2">
              <Clock className="mr-2 h-4 w-4" />
              Operating Hours
            </Label>
            
            <div className="space-y-4">
              <Controller
                name="operation_type"
                control={control}
                render={({ field }) => (
                  <RadioGroup
                    onValueChange={field.onChange}
                    value={field.value}
                    className="flex space-x-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="everyday" id="everyday" />
                      <Label htmlFor="everyday">Everyday</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="custom" id="custom" />
                      <Label htmlFor="custom">Custom Days</Label>
                    </div>
                  </RadioGroup>
                )}
              />
              
              {operationType === 'custom' && (
                <div className="pt-2">
                  <Label>Select Days</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 mt-2">
                    <Controller
                      name="custom_days"
                      control={control}
                      render={({ field }) => (
                        <>
                          {workingDays.map((day) => (
                            <div key={day.value} className="flex items-center space-x-2">
                              <Checkbox
                                id={`day-${day.value}`}
                                checked={(field.value || []).includes(day.value)}
                                onCheckedChange={(checked) => {
                                  const currentValue = field.value || [];
                                  const newValue = checked
                                    ? [...currentValue, day.value]
                                    : currentValue.filter((val) => val !== day.value);
                                  field.onChange(newValue);
                                }}
                              />
                              <Label htmlFor={`day-${day.value}`}>{day.label}</Label>
                            </div>
                          ))}
                        </>
                      )}
                    />
                  </div>
                  {errors.custom_days && (
                    <p className="text-sm text-red-500 mt-1">Please select at least one day</p>
                  )}
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="opening_time">Opening Time</Label>
                  <Input
                    id="opening_time"
                    type="time"
                    {...register("opening_time")}
                    className="bg-zinc-800 border-zinc-700 text-zinc-200 font-['Poppins']"
                  />
                  {errors.opening_time && (
                    <p className="text-sm text-red-500 mt-1">{errors.opening_time.message}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="closing_time">Closing Time</Label>
                  <Input
                    id="closing_time"
                    type="time"
                    {...register("closing_time")}
                    className="bg-zinc-800 border-zinc-700 text-zinc-200 font-['Poppins']"
                  />
                  {errors.closing_time && (
                    <p className="text-sm text-red-500 mt-1">{errors.closing_time.message}</p>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Image Upload */}
          <div className="bg-zinc-900 border border-zinc-700 rounded p-4">
            <Label className="flex items-center mb-2">
              <ImageIcon className="mr-2 h-4 w-4" />
              Coffee Shop Image
            </Label>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="space-y-2">
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/jpg,image/webp"
                  onChange={handleFileChange}
                  ref={fileInputRef}
                  className="hidden"
                />
                
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full rounded border-amber-700 text-amber-200 hover:bg-amber-900/20"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Upload Image
                </Button>
                
                <p className="text-xs text-zinc-400">
                  Upload a JPEG, PNG or WebP image (max 5MB)
                </p>
              </div>
              
              <div
                className={cn(
                  "border border-dashed border-zinc-700 rounded flex items-center justify-center overflow-hidden",
                  {"h-40": !imagePreview}
                )}
              >
                {imagePreview ? (
                  <div className="relative w-full h-40">
                    <img
                      src={imagePreview}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2 rounded-full w-6 h-6 p-0"
                      onClick={() => {
                        setImagePreview(null);
                        setValue('image_file', undefined);
                        if (fileInputRef.current) {
                          fileInputRef.current.value = '';
                        }
                      }}
                    >
                      ✕
                    </Button>
                  </div>
                ) : (
                  <span className="text-zinc-500">No image selected</span>
                )}
              </div>
            </div>
          </div>
          
          {/* Amenities Section */}
          <div className="bg-zinc-900 border border-zinc-700 rounded p-4">
            <Label className="mb-2 block">Amenities</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center justify-between rounded bg-zinc-800 p-3">
                <Label htmlFor="has_wifi" className="cursor-pointer font-['Poppins']">WiFi Available</Label>
                <Controller
                  name="has_wifi"
                  control={control}
                  render={({ field }) => (
                    <Switch
                      id="has_wifi"
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  )}
                />
              </div>
              
              <div className="flex items-center justify-between rounded bg-zinc-800 p-3">
                <Label htmlFor="is_al_fresco" className="cursor-pointer font-['Poppins']">Outdoor Seating</Label>
                <Controller
                  name="is_al_fresco"
                  control={control}
                  render={({ field }) => (
                    <Switch
                      id="is_al_fresco"
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  )}
                />
              </div>
              
              <div className="flex items-center justify-between rounded bg-zinc-800 p-3">
                <Label htmlFor="has_power_outlets" className="cursor-pointer font-['Poppins']">Power Outlets</Label>
                <Controller
                  name="has_power_outlets"
                  control={control}
                  render={({ field }) => (
                    <Switch
                      id="has_power_outlets"
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  )}
                />
              </div>
              
              <div className="flex items-center justify-between rounded bg-zinc-800 p-3">
                <Label htmlFor="is_pet_friendly" className="cursor-pointer font-['Poppins']">Pet Friendly</Label>
                <Controller
                  name="is_pet_friendly"
                  control={control}
                  render={({ field }) => (
                    <Switch
                      id="is_pet_friendly"
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  )}
                />
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button 
              type="button" 
              variant="outline"
              onClick={() => {
                setShowForm(false);
                setImagePreview(null);
                reset();
              }}
              className="rounded border-amber-700 text-amber-200 hover:bg-amber-900/20"
            >
              Cancel
            </Button>
            
            <Button 
              type="submit" 
              disabled={isSubmitting || isUploading}
              className="rounded bg-amber-700 hover:bg-amber-600 text-amber-50 border border-amber-800 shadow-md"
            >
              {isSubmitting || isUploading ? (
                <>
                  <Loader className="mr-2 h-4 w-4 animate-spin" />
                  {isUploading ? 'Uploading Image...' : 'Submitting...'}
                </>
              ) : (
                'Submit Coffee Shop'
              )}
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};

export default AddCoffeeShop;