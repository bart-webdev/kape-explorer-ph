import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Coffee, Search, Menu, X, LogIn, UserPlus, LogOut, PlusCircle, User } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';

/**
 * Header component with navigation links and mobile menu
 */
const Header: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
    setLocation('/');
  };

  return (
    <header className="bg-zinc-900 border-b-2 border-amber-800 sticky top-0 z-10 industrial-shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <Coffee className="h-8 w-8 text-amber-600" />
              <span className="ml-2 text-2xl font-['Bebas_Neue'] tracking-wider text-amber-100">KAPE<span className="text-amber-600">EXPLORER</span>PH</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center space-x-4">
            <Link href="/" className="text-zinc-300 hover:text-amber-300 px-3 py-2 text-sm font-medium uppercase tracking-wider font-['Roboto_Mono'] transition-colors duration-200">
              Home
            </Link>
            <a href="#about" className="text-zinc-300 hover:text-amber-300 px-3 py-2 text-sm font-medium uppercase tracking-wider font-['Roboto_Mono'] transition-colors duration-200">
              About
            </a>
            <a href="#contact" className="text-zinc-300 hover:text-amber-300 px-3 py-2 text-sm font-medium uppercase tracking-wider font-['Roboto_Mono'] transition-colors duration-200">
              Contact
            </a>
            {user && (
              <Link 
                href="/add-shop" 
                className="text-amber-300 hover:text-amber-100 px-3 py-2 text-sm font-medium uppercase tracking-wider font-['Roboto_Mono'] transition-colors duration-200 flex items-center"
              >
                <PlusCircle className="mr-1 h-4 w-4" />
                Add Shop
              </Link>
            )}
            <div className="ml-2 flex bg-zinc-800 border border-zinc-700 rounded-sm overflow-hidden">
              <input
                type="text"
                placeholder="Search..."
                className="px-3 py-1 bg-zinc-800 border-0 focus:outline-none text-zinc-200 text-sm w-32"
              />
              <button className="bg-amber-800 px-2 flex items-center justify-center">
                <Search size={16} className="text-amber-100" />
              </button>
            </div>
            
            {user ? (
              <div className="flex items-center space-x-3">
                <div className="text-zinc-400 text-xs flex items-center">
                  <User className="h-3 w-3 mr-1" />
                  <span>{user.username}</span>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleLogout} 
                  className="text-zinc-300 border-zinc-700 hover:bg-zinc-800"
                >
                  <LogOut className="mr-1 h-3 w-3" />
                  Sign out
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Button asChild variant="ghost" size="sm" className="text-zinc-300 hover:text-amber-300 hover:bg-zinc-800">
                  <Link href="/auth">
                    <LogIn className="mr-1 h-4 w-4" />
                    Sign in
                  </Link>
                </Button>
                <Button asChild variant="outline" size="sm" className="bg-amber-800 text-amber-100 border-amber-600 hover:bg-amber-700">
                  <Link href="/auth">
                    <UserPlus className="mr-1 h-4 w-4" />
                    Sign up
                  </Link>
                </Button>
              </div>
            )}
          </nav>
          <div className="md:hidden flex items-center">
            <button 
              type="button" 
              className="text-amber-100 p-1 rounded-sm border border-zinc-700 bg-zinc-800" 
              onClick={toggleMobileMenu}
              aria-label="Toggle mobile menu"
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div className={`${isMobileMenuOpen ? 'block' : 'hidden'} md:hidden bg-zinc-900 border-t border-zinc-800`}>
        <div className="px-4 pt-2 pb-3 space-y-2">
          <Link href="/" className="block py-2 text-base font-medium text-amber-100 border-b border-zinc-800 font-['Roboto_Mono']">
            HOME
          </Link>
          <a href="#about" className="block py-2 text-base font-medium text-zinc-300 hover:text-amber-300 border-b border-zinc-800 font-['Roboto_Mono']">
            ABOUT
          </a>
          <a href="#contact" className="block py-2 text-base font-medium text-zinc-300 hover:text-amber-300 border-b border-zinc-800 font-['Roboto_Mono']">
            CONTACT
          </a>
          
          {user && (
            <Link 
              href="/add-shop" 
              className="block py-2 text-base font-medium text-amber-300 hover:text-amber-100 border-b border-zinc-800 font-['Roboto_Mono'] flex items-center"
            >
              <PlusCircle className="mr-2 h-5 w-5" />
              ADD SHOP
            </Link>
          )}
          
          <div className="py-2 flex items-center">
            <input
              type="text"
              placeholder="Search..."
              className="industrial-input px-3 py-1 text-zinc-200 text-sm flex-grow"
            />
            <button className="bg-amber-800 px-2 py-1 flex items-center justify-center border-2 border-amber-900">
              <Search size={16} className="text-amber-100" />
            </button>
          </div>
          
          {user ? (
            <div className="pt-2 border-t border-zinc-800">
              <div className="flex justify-between items-center mb-3">
                <div className="text-zinc-400 text-sm flex items-center">
                  <User className="h-4 w-4 mr-1" />
                  <span>{user.username}</span>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleLogout} 
                  className="text-zinc-300 border-zinc-700"
                >
                  <LogOut className="mr-1 h-4 w-4" />
                  Sign out
                </Button>
              </div>
            </div>
          ) : (
            <div className="pt-2 border-t border-zinc-800 grid grid-cols-2 gap-2">
              <Button asChild variant="outline" className="bg-transparent text-zinc-300 border-zinc-700">
                <Link href="/auth">
                  <LogIn className="mr-1 h-4 w-4" />
                  Sign in
                </Link>
              </Button>
              <Button asChild className="bg-amber-800 text-amber-100 border-amber-600 hover:bg-amber-700">
                <Link href="/auth">
                  <UserPlus className="mr-1 h-4 w-4" />
                  Sign up
                </Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
