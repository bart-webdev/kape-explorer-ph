import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { fetchReviewsByCoffeeShopId, addReview } from '@/lib/supabaseClient';
import { Review, InsertReview } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Star, Clock, User, Calendar, LogIn } from 'lucide-react';
import { Loader } from 'lucide-react';
import { format } from 'date-fns';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertReviewSchema } from '@shared/schema';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { Link } from 'wouter';

interface ReviewsProps {
  coffeeShopId: string;
  coffeeShopName: string;
}

const reviewFormSchema = insertReviewSchema.omit({ coffee_shop_id: true, user_name: true });
type ReviewFormData = z.infer<typeof reviewFormSchema>;

const ReviewForm: React.FC<{ coffeeShopId: string; coffeeShopName: string; onReviewAdded: () => void }> = ({
  coffeeShopId,
  coffeeShopName,
  onReviewAdded
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  
  const { register, handleSubmit, control, reset, formState: { errors, isSubmitting } } = useForm<ReviewFormData>({
    resolver: zodResolver(reviewFormSchema),
    defaultValues: {
      rating: 5,
      comment: '',
    }
  });
  
  const addReviewMutation = useMutation({
    mutationFn: (newReview: InsertReview) => addReview(newReview),
    onSuccess: () => {
      // Invalidate and refetch reviews for this coffee shop
      queryClient.invalidateQueries({ queryKey: [`coffee-shop-reviews-${coffeeShopId}`] });
      reset();
      onReviewAdded();
      toast({
        title: "Review submitted!",
        description: "Thanks for sharing your experience.",
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Error submitting review",
        description: `${error}`,
        variant: "destructive",
      });
    }
  });
  
  const onSubmit = (data: ReviewFormData) => {
    // Use the user's display name or username
    const userName = user?.display_name || user?.username || '';
    
    const newReview: InsertReview = {
      ...data,
      user_name: userName,
      coffee_shop_id: coffeeShopId,
      user_id: user?.id, // Add the user ID for tracking ownership
      visit_date: new Date()
    };
    
    addReviewMutation.mutate(newReview);
  };
  
  // Display the user's name that will be used for the review
  const userName = user?.display_name || user?.username || '';
  
  return (
    <div className="bg-zinc-800 border border-zinc-700/70 rounded p-6 shadow-md">
      <h3 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100 mb-4">
        WRITE A REVIEW
      </h3>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="bg-zinc-900/50 p-3 rounded border border-zinc-700/50 mb-2">
          <p className="text-zinc-400 text-sm font-['Poppins']">
            Posting as <span className="text-amber-400 font-medium">{userName}</span>
          </p>
        </div>
        
        <div>
          <Label htmlFor="rating">Rating</Label>
          <div className="flex items-center space-x-2">
            <Controller
              control={control}
              name="rating"
              render={({ field }) => (
                <>
                  {[1, 2, 3, 4, 5].map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => field.onChange(value)}
                      className={`h-8 w-8 rounded ${
                        value <= field.value 
                          ? 'text-amber-400 bg-zinc-700/50' 
                          : 'text-zinc-600 bg-zinc-800/50'
                      }`}
                      aria-label={`Rate ${value} star${value !== 1 ? 's' : ''}`}
                    >
                      <Star className={`h-6 w-6 mx-auto ${value <= field.value ? 'fill-amber-400' : ''}`} />
                    </button>
                  ))}
                </>
              )}
            />
          </div>
          {errors.rating && (
            <p className="text-sm text-red-500 mt-1">{errors.rating.message}</p>
          )}
        </div>
        
        <div>
          <Label htmlFor="comment">Your Experience</Label>
          <Textarea
            id="comment"
            {...register("comment")}
            placeholder={`What did you think about ${coffeeShopName}?`}
            className="bg-zinc-900 border-zinc-700 text-zinc-200 min-h-[100px] font-['Poppins']"
          />
          {errors.comment && (
            <p className="text-sm text-red-500 mt-1">{errors.comment.message}</p>
          )}
        </div>
        
        <Button 
          type="submit" 
          disabled={isSubmitting}
          className="rounded bg-amber-700 hover:bg-amber-600 text-amber-50 border border-amber-800 shadow-md w-full"
        >
          {isSubmitting ? (
            <>
              <Loader className="mr-2 h-4 w-4 animate-spin" />
              Submitting...
            </>
          ) : (
            'Submit Review'
          )}
        </Button>
      </form>
    </div>
  );
};

const ReviewCard: React.FC<{ review: Review }> = ({ review }) => {
  // Generate star rating display
  const starRating = () => {
    return Array.from({ length: 5 }).map((_, index) => (
      <Star 
        key={index} 
        className={`h-4 w-4 ${index < review.rating ? 'text-amber-400 fill-amber-400' : 'text-zinc-600'}`} 
      />
    ));
  };
  
  // Format dates
  const formatDate = (date: any): string => {
    if (!date) return '';
    return format(new Date(date), 'MMM d, yyyy');
  };
  
  const formattedVisitDate = formatDate(review.visit_date);
  const formattedCreatedDate = formatDate(review.created_at);
  
  return (
    <div className="bg-zinc-800/50 border border-zinc-700/40 p-4 rounded mb-4">
      <div className="flex justify-between mb-2">
        <div className="flex items-center">
          <User className="h-5 w-5 text-amber-500 mr-2" />
          <span className="text-zinc-200 font-['Poppins'] font-medium">{review.user_name}</span>
        </div>
        <div className="flex items-center">{starRating()}</div>
      </div>
      
      <p className="text-zinc-300 my-3 font-['Poppins']">{review.comment}</p>
      
      <div className="flex justify-between text-xs text-zinc-500 font-['Poppins']">
        {review.visit_date && (
          <div className="flex items-center">
            <Calendar className="h-3 w-3 mr-1" />
            <span>Visited: {formattedVisitDate}</span>
          </div>
        )}
        <div className="flex items-center">
          <Clock className="h-3 w-3 mr-1" />
          <span>Posted: {formattedCreatedDate}</span>
        </div>
      </div>
    </div>
  );
};

const Reviews: React.FC<ReviewsProps> = ({ coffeeShopId, coffeeShopName }) => {
  const [showReviewForm, setShowReviewForm] = React.useState(false);
  const { user } = useAuth();
  
  const { data: reviews, isLoading, error } = useQuery<Review[]>({
    queryKey: [`coffee-shop-reviews-${coffeeShopId}`],
    queryFn: async () => {
      try {
        return await fetchReviewsByCoffeeShopId(coffeeShopId);
      } catch (err) {
        console.error("Error fetching reviews:", err);
        return [];
      }
    },
  });
  
  // Handle loading state
  if (isLoading) {
    return (
      <div className="py-6 text-center">
        <Loader className="h-8 w-8 text-amber-600 animate-spin mx-auto mb-2" />
        <p className="text-zinc-400 font-['Poppins']">Loading reviews...</p>
      </div>
    );
  }
  
  // Handle error state
  if (error) {
    return (
      <div className="py-6 text-center">
        <p className="text-red-500 mb-2">Failed to load reviews</p>
        <p className="text-zinc-400 text-sm">{String(error)}</p>
      </div>
    );
  }
  
  // Render the write review button based on authentication status
  const renderWriteReviewButton = () => {
    if (user) {
      // User is logged in
      return (
        <Button 
          onClick={() => setShowReviewForm(true)}
          className="rounded bg-amber-700 hover:bg-amber-600 text-amber-50 text-sm border border-amber-800 shadow-md"
        >
          Write a Review
        </Button>
      );
    } else {
      // User is not logged in
      return (
        <Button 
          asChild
          className="rounded bg-amber-700 hover:bg-amber-600 text-amber-50 text-sm border border-amber-800 shadow-md"
        >
          <Link href="/auth">
            <LogIn className="mr-2 h-4 w-4" />
            Sign in to Review
          </Link>
        </Button>
      );
    }
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-['Bebas_Neue'] tracking-wider text-amber-100">
          REVIEWS
        </h2>
        {!showReviewForm && renderWriteReviewButton()}
      </div>
      
      {showReviewForm && user && (
        <div className="mb-8">
          <ReviewForm 
            coffeeShopId={coffeeShopId} 
            coffeeShopName={coffeeShopName} 
            onReviewAdded={() => setShowReviewForm(false)} 
          />
        </div>
      )}
      
      {reviews && reviews.length > 0 ? (
        <div className="space-y-4">
          {reviews.map((review: Review) => (
            <ReviewCard key={review.id} review={review} />
          ))}
        </div>
      ) : (
        <div className="bg-zinc-800/50 border border-zinc-700/40 rounded p-8 text-center">
          <p className="text-zinc-400 mb-4 font-['Poppins']">No reviews yet.</p>
          {!showReviewForm && (
            user ? (
              <Button 
                onClick={() => setShowReviewForm(true)}
                className="rounded bg-amber-700 hover:bg-amber-600 text-amber-50 border border-amber-800 shadow-md text-sm"
              >
                Be the First to Review
              </Button>
            ) : (
              <Button 
                asChild
                className="rounded bg-amber-700 hover:bg-amber-600 text-amber-50 text-sm border border-amber-800 shadow-md"
              >
                <Link href="/auth">
                  <LogIn className="mr-2 h-4 w-4" />
                  Sign in to be the First Reviewer
                </Link>
              </Button>
            )
          )}
        </div>
      )}
    </div>
  );
};

export default Reviews;