import { Coffee, Facebook, Instagram, Twitter } from 'lucide-react';
import { Link } from 'wouter';
import BuyMeACoffeeButton from './BuyMeACoffeeButton';

/**
 * Footer component with site information and donation button
 */
const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-zinc-900 border-t-2 border-amber-800 mt-auto">
      <div className="industrial-divider"></div>
      
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex justify-center md:justify-start">
            <Link href="/" className="flex items-center group">
              <Coffee className="h-8 w-8 text-amber-600 transform group-hover:rotate-12 transition-transform duration-300" />
              <span className="ml-2 text-2xl font-['Bebas_Neue'] tracking-wider text-amber-100">
                KAPE<span className="text-amber-600">EXPLORER</span>PH
              </span>
            </Link>
          </div>
          
          {/* Buy Me A Coffee Button */}
          <div className="mt-8 md:mt-0">
            <BuyMeACoffeeButton />
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mt-12 border-t border-zinc-800 pt-8">
          {/* Column 1: About */}
          <div>
            <h4 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100 mb-4">ABOUT US</h4>
            <p className="text-zinc-400 text-sm">
              KapeExplorer PH is your guide to the best coffee shops around Metro Manila. 
              Discover new brewing spots, find places with great amenities, and explore the coffee scene.
            </p>
          </div>
          
          {/* Column 2: Links */}
          <div>
            <h4 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100 mb-4">QUICK LINKS</h4>
            <nav className="flex flex-col space-y-2">
              <Link href="/" className="text-zinc-400 hover:text-amber-300 transition-colors duration-200 text-sm font-['Roboto_Mono']">
                HOME
              </Link>
              <a href="#about" className="text-zinc-400 hover:text-amber-300 transition-colors duration-200 text-sm font-['Roboto_Mono']">
                ABOUT
              </a>
              <a href="#contact" className="text-zinc-400 hover:text-amber-300 transition-colors duration-200 text-sm font-['Roboto_Mono']">
                CONTACT
              </a>
            </nav>
          </div>
          
          {/* Column 3: Social */}
          <div>
            <h4 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100 mb-4">CONNECT</h4>
            <div className="flex space-x-4">
              <a href="#" className="bg-zinc-800 text-amber-500 hover:text-amber-300 p-2 rounded-sm border border-zinc-700 
                hover:border-amber-800 transition-colors duration-200" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="#" className="bg-zinc-800 text-amber-500 hover:text-amber-300 p-2 rounded-sm border border-zinc-700 
                hover:border-amber-800 transition-colors duration-200" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="bg-zinc-800 text-amber-500 hover:text-amber-300 p-2 rounded-sm border border-zinc-700 
                hover:border-amber-800 transition-colors duration-200" aria-label="Twitter">
                <Twitter size={20} />
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-zinc-800 text-center">
          <p className="text-xs text-zinc-500 font-['Roboto_Mono'] tracking-wider">
            &copy; {currentYear} KAPEEXPLORER PH. ALL RIGHTS RESERVED.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
