import { Wifi, MapPin, Zap, Heart, SlidersHorizontal } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

interface FilterState {
  hasWifi: boolean;
  isAlFresco: boolean;
  hasPowerOutlets: boolean;
  isPetFriendly: boolean;
}

interface FiltersProps {
  filters: FilterState;
  onChange: (filters: FilterState) => void;
}

/**
 * Filters component for filtering coffee shops by amenities
 */
const Filters: React.FC<FiltersProps> = ({ filters, onChange }) => {
  const handleFilterChange = (filterName: keyof FilterState) => {
    const updatedFilters = {
      ...filters,
      [filterName]: !filters[filterName]
    };
    onChange(updatedFilters);
  };

  return (
    <div className="bg-zinc-800 border-2 border-zinc-700 p-5 industrial-shadow">
      <div className="flex items-center border-b border-zinc-700 pb-3 mb-5">
        <SlidersHorizontal className="h-5 w-5 text-amber-500 mr-2" />
        <h3 className="text-xl font-['Bebas_Neue'] tracking-wider text-amber-100">FILTER RESULTS</h3>
      </div>
      
      <div className="space-y-4">
        <div className="border border-zinc-700 p-3 rounded-sm transition-all duration-200
           hover:border-amber-800 hover:bg-zinc-900/50">
          <div className="flex items-center">
            <Checkbox
              id="filter-wifi"
              checked={filters.hasWifi}
              onCheckedChange={() => handleFilterChange('hasWifi')}
              className="border-zinc-600 data-[state=checked]:bg-amber-700 data-[state=checked]:border-amber-700"
            />
            <div className="ml-3 flex items-center cursor-pointer" onClick={() => handleFilterChange('hasWifi')}>
              <Wifi className="h-4 w-4 text-amber-500 mr-2" />
              <Label 
                htmlFor="filter-wifi" 
                className="text-sm text-zinc-300 cursor-pointer font-['Roboto_Mono'] uppercase tracking-wider"
              >
                Wi-Fi
              </Label>
            </div>
          </div>
        </div>

        <div className="border border-zinc-700 p-3 rounded-sm transition-all duration-200
           hover:border-amber-800 hover:bg-zinc-900/50">
          <div className="flex items-center">
            <Checkbox
              id="filter-alfresco"
              checked={filters.isAlFresco}
              onCheckedChange={() => handleFilterChange('isAlFresco')}
              className="border-zinc-600 data-[state=checked]:bg-amber-700 data-[state=checked]:border-amber-700"
            />
            <div className="ml-3 flex items-center cursor-pointer" onClick={() => handleFilterChange('isAlFresco')}>
              <MapPin className="h-4 w-4 text-amber-500 mr-2" />
              <Label 
                htmlFor="filter-alfresco" 
                className="text-sm text-zinc-300 cursor-pointer font-['Roboto_Mono'] uppercase tracking-wider"
              >
                Al Fresco
              </Label>
            </div>
          </div>
        </div>

        <div className="border border-zinc-700 p-3 rounded-sm transition-all duration-200
           hover:border-amber-800 hover:bg-zinc-900/50">
          <div className="flex items-center">
            <Checkbox
              id="filter-power"
              checked={filters.hasPowerOutlets}
              onCheckedChange={() => handleFilterChange('hasPowerOutlets')}
              className="border-zinc-600 data-[state=checked]:bg-amber-700 data-[state=checked]:border-amber-700"
            />
            <div className="ml-3 flex items-center cursor-pointer" onClick={() => handleFilterChange('hasPowerOutlets')}>
              <Zap className="h-4 w-4 text-amber-500 mr-2" />
              <Label 
                htmlFor="filter-power" 
                className="text-sm text-zinc-300 cursor-pointer font-['Roboto_Mono'] uppercase tracking-wider"
              >
                Power Outlets
              </Label>
            </div>
          </div>
        </div>

        <div className="border border-zinc-700 p-3 rounded-sm transition-all duration-200
           hover:border-amber-800 hover:bg-zinc-900/50">
          <div className="flex items-center">
            <Checkbox
              id="filter-pet"
              checked={filters.isPetFriendly}
              onCheckedChange={() => handleFilterChange('isPetFriendly')}
              className="border-zinc-600 data-[state=checked]:bg-amber-700 data-[state=checked]:border-amber-700"
            />
            <div className="ml-3 flex items-center cursor-pointer" onClick={() => handleFilterChange('isPetFriendly')}>
              <Heart className="h-4 w-4 text-amber-500 mr-2" />
              <Label 
                htmlFor="filter-pet" 
                className="text-sm text-zinc-300 cursor-pointer font-['Roboto_Mono'] uppercase tracking-wider"
              >
                Pet Friendly
              </Label>
            </div>
          </div>
        </div>
      </div>
      
      <button 
        className="mt-5 w-full py-2 font-['Roboto_Mono'] text-xs tracking-wider uppercase"
        onClick={() => onChange({ hasWifi: false, isAlFresco: false, hasPowerOutlets: false, isPetFriendly: false })}
      >
        Reset Filters
      </button>
    </div>
  );
};

export default Filters;
