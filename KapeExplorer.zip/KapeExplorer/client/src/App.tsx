import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "./components/ui/toaster";
import NotFound from "./pages/not-found";
import HomePage from "./pages/HomePage";
import ShopDetailPage from "./pages/ShopDetailPage";
import AuthPage from "./pages/auth-page";
import { ProtectedRoute } from "./lib/protected-route";
import Header from "./components/Header";
import Footer from "./components/Footer";
import { AuthProvider } from "./hooks/use-auth";

function Router() {
  return (
    <div className="min-h-screen flex flex-col">
      <Switch>
        <Route path="/auth">
          <AuthPage />
        </Route>
        <Route path="/add-shop">
          <ProtectedRoute path="/add-shop" component={() => (
            <>
              <Header />
              <div className="flex-grow">
                {/* Add shop form will go here */}
                <div className="container mx-auto py-8">
                  <h1 className="text-2xl font-bold mb-4">Add New Coffee Shop</h1>
                  <p>This feature is coming soon!</p>
                </div>
              </div>
              <Footer />
            </>
          )} />
        </Route>
        <Route>
          <Header />
          <div className="flex-grow">
            <Switch>
              <Route path="/">
                <HomePage />
              </Route>
              <Route path="/shop/:id">
                <ShopDetailPage />
              </Route>
              <Route>
                <NotFound />
              </Route>
            </Switch>
          </div>
          <Footer />
        </Route>
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
