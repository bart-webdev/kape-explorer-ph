import { pgTable, text, serial, integer, boolean, uuid, numeric, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  display_name: text("display_name"),
  avatar_url: text("avatar_url"),
  role: text("role").notNull().default("user"), // "user" or "owner"
  created_at: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  created_at: true,
}).extend({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters long"),
  username: z.string().min(3, "Username must be at least 3 characters long"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Schema for shop ownership - links users with coffee shops they own
export const shopOwnership = pgTable("shop_ownership", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  coffee_shop_id: uuid("coffee_shop_id").notNull().references(() => coffeeShops.id, { onDelete: 'cascade' }),
  created_at: timestamp("created_at").defaultNow(),
});

export const insertShopOwnershipSchema = createInsertSchema(shopOwnership).omit({
  id: true,
  created_at: true,
});

export type InsertShopOwnership = z.infer<typeof insertShopOwnershipSchema>;
export type ShopOwnership = typeof shopOwnership.$inferSelect;

// Coffee shop schema
export const coffeeShops = pgTable("coffee_shops", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  operating_hours: text("operating_hours").notNull(),
  image_url: text("image_url"),
  latitude: numeric("latitude"),
  longitude: numeric("longitude"),
  has_wifi: boolean("has_wifi").default(false),
  is_al_fresco: boolean("is_al_fresco").default(false),
  has_power_outlets: boolean("has_power_outlets").default(false),
  is_pet_friendly: boolean("is_pet_friendly").default(false),
});

export const insertCoffeeShopSchema = createInsertSchema(coffeeShops).omit({
  id: true,
});

export type InsertCoffeeShop = z.infer<typeof insertCoffeeShopSchema>;
export type CoffeeShop = typeof coffeeShops.$inferSelect;

// Reviews schema
export const reviews = pgTable("reviews", {
  id: uuid("id").primaryKey().defaultRandom(),
  coffee_shop_id: uuid("coffee_shop_id").notNull().references(() => coffeeShops.id, { onDelete: 'cascade' }),
  user_id: integer("user_id").references(() => users.id),
  user_name: text("user_name").notNull(), // In case the user doesn't want to register
  rating: integer("rating").notNull(),
  comment: text("comment"),
  visit_date: timestamp("visit_date").defaultNow(),
  created_at: timestamp("created_at").defaultNow(),
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  created_at: true,
}).extend({
  rating: z.number().min(1).max(5),
  comment: z.string().min(3).max(500),
  user_name: z.string().min(2).max(50),
});

export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;
